# @elftia/three-assets

Owned, offline resource loading for **three@0.185.1**. MIT; see LICENSE and
PROVENANCE.md. No Director application, React, filesystem, fetch or CDN dependency.

## Contract

```ts
import { loadModel } from "@elftia/three-assets";

const model = await loadModel(
  { id: "model-id", mediaType: "model/gltf-binary", byteLength, sha256 },
  { resolver, limits, signal },
);
const instance = model.createInstance();
scene.add(instance.value);
model.dispose(); // Stops new instances, but does not invalidate this live lease.
instance.dispose(); // Detaches scene and releases the final retained resources.
```

`resolver.read(id, signal?)` returns an authorized ArrayBuffer. The caller bounds
the transport allocation; the package verifies length and SHA-256 on its own copy.
Version 0.1.1 accepts an optional trusted `digestSha256(bytes): Promise<ArrayBuffer>`
adapter for opaque-origin sandboxes without Web Crypto. It receives another copy
and must return the real 32-byte digest; length/hash comparison remains mandatory.
Without an adapter, native Web Crypto is required. Do not provide this hook from
untrusted project configuration or replace it with an expected-hash shortcut.
Limits are mandatory: `maxBytes`, `maxDecodedBytes`, `maxDimension`, `maxObjects`.
They are not project policy defaults. In particular, Director's limits must not
silently replace Rocut's smaller attachment limits.

`loadTexture(descriptor, { ...options, role: "color" | "data", flipY?: boolean })`
returns `{ value: Texture, dispose() }`. Color maps use sRGB, data maps use no color
space. Default vertical flip is true. ImageBitmap orientation is set at decode,
with alpha unpremultiplied and browser color conversion disabled.

`loadEnvironment(descriptor, options)` returns an equirectangular linear-sRGB
Float32 DataTexture. HDR supports standard `-Y +X` Radiance RGBE. EXR accepts
single-part, non-subsampled HALF/FLOAT scanlines and tiles with NONE, RLE, ZIPS,
ZIP, PIZ, PXR24, B44, B44A, DWAA or DWAB compression. Deep/multipart, UINT image
channels, subsampling and ripmaps remain unsupported. ONE_LEVEL tiles have been
reference-tested; mipmap validation exists but product support is not claimed.

Equirectangular inputs narrower than 64 pixels are resampled to r185 PMREM's
minimum face size (16): width 64 and proportionally rounded-up height. Bilinear
pixel-center sampling wraps horizontally and clamps vertically, without clamping
HDR radiance or converting its color space. The normalized texture records original
dimensions in `userData.environmentSourceDimensions`; descriptor/hash/encoded bytes
remain unchanged. Both decoded and resampled buffers must fit the caller's byte
budget during normalization, and output dimensions must fit `maxDimension`.

EXR metadata and compressed sections are preflighted before Three's parser.
For r185's DWA DEFLATE AC span bug, the validated private decoding copy receives
a narrow count-to-byte-span correction. Original caller bytes and their hash are
unchanged. Twenty self-authored OpenEXR 3.3.3 reference fixtures cover the ten
codecs in scanline/ONE_LEVEL forms; DWA is compared with a lossy pixel tolerance.

Models use self-contained GLB 2.0, embedded buffer views or bounded base64 data
URIs. PNG, JPEG and non-animated WebP are accepted. External references, required
unknown extensions, Draco, Meshopt, KTX2 and GPU instancing are rejected. No
decoder downloads or global URL/Three Cache mutation occur. Embedded images are
decoded before parsing, so a bad image cannot silently become a null map.

Each model instance has independent bones, materials, texture objects and clips.
Geometry and decoded image pixels are shared **read-only** and retained until all
leases end. Do not mutate shared geometry/images or dispose Three objects by hand.
Dispose the instance/asset handle instead. All public disposal is idempotent.
The loader uses the default scene, while owning parsed resources in all scenes.

Abort rejects with `AbortError` and never publishes success. Three parsing and
ImageBitmap decoding are not synchronously interruptible; late resources are
disposed. A fulfilled handle belongs to the caller, not its former AbortSignal.
Readiness means decoded resources, not an uploaded/rendered GPU frame. Consumers
must wait for scene attachment and their renderer's frame-completion boundary.

Header, graph and allocation preflight is defense in depth, not a replacement for
the caller's untrusted-content isolation and process/memory budget. Worker and
OffscreenCanvas support are not claimed without separate runtime verification.
Node can load untextured GLB and environments; textures require ImageBitmap or an
injected decoder implementing the same orientation and ownership contract.

## Development

`npm run build`, `npm run typecheck`, `npm test`. Build emits portable ESM/types
without bundling Three. `npm pack` includes only dist/source, this README, LICENSE
and provenance. Independent archive-consumer and browser checks are required
before declaring the package integrated or distributable.

From a copied Director source fixture, `npm run e2e:three-assets:shared` exercises
actual browser decoding/rendering, and `npm run test:three-assets:package` installs
the archive in a separate temporary consumer, checks public types and runs it
without workspace links. Neither command publishes or installs a user plugin.

Director now consumes this package through its viewport-owned resource cache.
After building Studio and its dependencies in a copied source fixture,
`npm run e2e:director-assets` exercises real Host/Studio preview, random seek,
viewport resizing, two independent model instances, texture/environment use,
WebCodecs output with independent decoding and project bundle restoration.
`npm run e2e:director-assets:lifecycle` uses development React StrictMode to
verify effect replay, committed model leases, removal, unmount, pending-read
cancellation and integrity-failure recovery. These are not Rocut acceptance.
