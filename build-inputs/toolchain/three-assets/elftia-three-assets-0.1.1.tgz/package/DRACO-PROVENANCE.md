# Fixed Draco decoder

`src/draco-decoder.ts` is the JavaScript glTF Draco decoder distributed in
Three.js 0.185.1 at `examples/jsm/libs/draco/gltf/draco_decoder.js`.
Its UMD export suffix is replaced by an ESM default export and a TypeScript
checking directive is added. Node filesystem discovery is disabled because the
module is self-contained and has no external payload to load.

Draco is licensed under Apache-2.0. See
https://github.com/google/draco/blob/main/LICENSE and the decoder copyright
notices retained in the source. This module does not load external decoder
scripts, WASM, workers, or author supplied URLs.
