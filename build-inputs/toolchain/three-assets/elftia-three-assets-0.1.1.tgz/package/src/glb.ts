import { imageDimensions } from "./image.js";
import { integer, list, record, validateAccessors, validateJson } from "./glb-validation.js";
import { boundedDimensions } from "./ownership.js";
import { AssetError, type LoadOptions } from "./types.js";
import { decodeMeshoptViews, planMeshoptViews } from "./meshopt.js";
import { decodeDraco, planDraco } from "./draco.js";
import { ktx2Dimensions } from "./ktx2.js";
import { normalizeBasisuTextures } from "./ktx2-glb.js";

export interface EmbeddedImage { bytes: ArrayBuffer; mediaType: string }
export interface GlbContents { json: Record<string, unknown>; buffers: (ArrayBuffer | undefined)[]; views: ArrayBuffer[]; images: EmbeddedImage[] }

function dataUri(uri: unknown, allowed: readonly string[], maximum: number): EmbeddedImage {
  if (typeof uri !== "string") throw new AssetError("INVALID_ASSET", "Missing embedded data URI");
  const match = /^data:([^;,]+);base64,([A-Za-z0-9+/]*={0,2})$/u.exec(uri);
  if (!match || !allowed.includes(match[1]!)) throw new AssetError("UNSUPPORTED", "External or unsupported glTF URI is forbidden");
  const payload = match[2]!;
  if (payload.length % 4 !== 0) throw new AssetError("INVALID_ASSET", "Invalid base64 data URI");
  if (payload.length / 4 * 3 > maximum + 2) throw new AssetError("LIMIT_EXCEEDED", "Embedded data URI exceeds byte limit");
  let text: string;
  try { text = atob(payload); } catch { throw new AssetError("INVALID_ASSET", "Invalid base64 data URI"); }
  return { bytes: Uint8Array.from(text, (character) => character.charCodeAt(0)).buffer, mediaType: match[1]! };
}

/** No network or Three.js allocation occurs until this preflight succeeds. */
export async function inspectGlb(bytes: ArrayBuffer, options: LoadOptions): Promise<GlbContents> {
  if (bytes.byteLength < 20) throw new AssetError("INVALID_ASSET", "Truncated GLB header");
  const data = new DataView(bytes);
  if (data.getUint32(0, true) !== 0x46546c67 || data.getUint32(4, true) !== 2 || data.getUint32(8, true) !== bytes.byteLength) {
    throw new AssetError("INVALID_ASSET", "Invalid GLB 2.0 container");
  }
  let jsonBytes: ArrayBuffer | undefined;
  let bin: ArrayBuffer | undefined;
  for (let offset = 12; offset < bytes.byteLength;) {
    if (offset + 8 > bytes.byteLength) throw new AssetError("INVALID_ASSET", "Truncated GLB chunk");
    const length = data.getUint32(offset, true);
    const kind = data.getUint32(offset + 4, true);
    if (length % 4 || offset + 8 + length > bytes.byteLength) throw new AssetError("INVALID_ASSET", "Invalid GLB chunk size");
    if (kind === 0x4e4f534a && offset === 12) jsonBytes = bytes.slice(offset + 8, offset + 8 + length);
    else if (kind === 0x004e4942 && jsonBytes && !bin) bin = bytes.slice(offset + 8, offset + 8 + length);
    else throw new AssetError("UNSUPPORTED", "Unexpected GLB chunk");
    offset += 8 + length;
  }
  if (!jsonBytes) throw new AssetError("INVALID_ASSET", "Missing GLB JSON");
  let parsed: unknown;
  try { parsed = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(jsonBytes)); }
  catch { throw new AssetError("INVALID_ASSET", "Invalid GLB JSON encoding or syntax"); }
  const json = record(parsed);
  validateJson(json, options);
  let allocated = 0;
  const account = (count: number): void => {
    allocated += count;
    if (!Number.isSafeInteger(allocated) || allocated > options.limits.maxDecodedBytes) throw new AssetError("LIMIT_EXCEEDED", "glTF decoded resource budget exceeded");
  };
  const buffers = list(json.buffers).map((raw, index) => {
    const buffer = record(raw);
    const length = integer(buffer.byteLength, options.limits.maxDecodedBytes, 1);
    // Meshopt-required GLBs may declare URI-less logical fallback buffers.
    // They are never allocated/read; every reference is checked below.
    if (buffer.uri === undefined && index !== 0) return undefined;
    const source = buffer.uri === undefined && index === 0 ? bin : dataUri(buffer.uri, ["application/octet-stream", "application/gltf-buffer"], options.limits.maxBytes).bytes;
    if (!source || source.byteLength < length || source.byteLength - length > (buffer.uri === undefined ? 3 : 0)) throw new AssetError("INVALID_ASSET", "GLB buffer length mismatch");
    account(length);
    return source.slice(0, length);
  });
  const plans = planMeshoptViews(json, buffers, options, account);
  const dracoPlans = planDraco(json, options, account);
  const layouts = list(json.bufferViews).map((raw, index) => {
    const view = record(raw);
    const bufferIndex = integer(view.buffer, buffers.length - 1);
    const bufferLength = integer(record(list(json.buffers)[bufferIndex]).byteLength, options.limits.maxDecodedBytes, 1);
    const start = integer(view.byteOffset ?? 0, bufferLength);
    const length = integer(view.byteLength, bufferLength, 1);
    if (start + length > bufferLength || !plans[index] && !buffers[bufferIndex]) throw new AssetError("INVALID_ASSET", "GLB buffer view exceeds buffer");
    account(length);
    return { byteLength: length, bufferIndex, start };
  });
  // Accessor and sparse ranges are validated against logical decoded sizes before output allocation.
  account(validateAccessors(json, layouts, options, false));
  const views = layouts.map((layout, index) => plans[index] ? new ArrayBuffer(0) : buffers[layout.bufferIndex]!.slice(layout.start, layout.start + layout.byteLength));
  // Validate plain sparse indices before decoding any compressed view as well.
  validateAccessors(json, layouts.map((layout, index) => plans[index] ? layout : views[index]!), options, false);
  const images = list(json.images).map((raw) => {
    const image = record(raw);
    if (image.uri !== undefined && image.bufferView !== undefined) throw new AssetError("INVALID_ASSET", "Ambiguous glTF image source");
    if (image.bufferView !== undefined && plans[integer(image.bufferView, views.length - 1)]) throw new AssetError("UNSUPPORTED", "Meshopt-compressed image views are not supported");
    const result = image.uri !== undefined
      ? dataUri(image.uri, ["image/png", "image/jpeg", "image/webp", "image/ktx2"], options.limits.maxBytes)
      : { bytes: views[integer(image.bufferView, views.length - 1)]!, mediaType: String(image.mimeType) };
    if (image.mimeType !== undefined && image.mimeType !== result.mediaType) throw new AssetError("INVALID_ASSET", "Embedded image MIME mismatch");
    if (result.mediaType === "image/ktx2") {
      account(ktx2Dimensions(result.bytes, options).decodedBytes);
    } else {
      const [width, height] = imageDimensions(result.bytes, result.mediaType);
      boundedDimensions(width, height, 4, options);
      account(width * height * 4);
    }
    return result;
  });
  normalizeBasisuTextures(json, images);
  await decodeMeshoptViews(plans, buffers, views, options);
  await decodeDraco(dracoPlans, json, views, options);
  validateAccessors(json, views, options);
  return { json, buffers, views, images };
}
