import { LoadingManager, Mesh, MeshBasicMaterial, PropertyBinding, SkinnedMesh, type Object3D } from "three";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import { inspectGlb } from "./glb.js";
import { checkActive, ownedLoad, readVerified } from "./ownership.js";
import { AssetError, type AssetDescriptor, type LoadOptions } from "./types.js";

/** Read real loader AnimationClips without image decoding, playback, or author code. */
export async function loadModelAnimationCatalog(asset: AssetDescriptor, options: LoadOptions) {
  return ownedLoad(options, async (scope) => {
    if (asset.mediaType !== "model/gltf-binary") throw new AssetError("UNSUPPORTED", "Animation inspection requires a self-contained GLB");
    const contents = await inspectGlb(await readVerified(asset, options), options);
    scope.onDispose(() => { contents.views.length = 0; contents.buffers.length = 0; contents.images.length = 0; });
    const animations = contents.json.animations;
    const nodes = Array.isArray(contents.json.nodes) ? contents.json.nodes : [];
    const accessors = Array.isArray(contents.json.accessors) ? contents.json.accessors : [];
    if (animations !== undefined && !Array.isArray(animations)) throw new AssetError("INVALID_ASSET", "Invalid GLB animations");
    let channelCount = 0;
    for (const animation of animations ?? []) {
      if (!animation || !Array.isArray(animation.channels) || !Array.isArray(animation.samplers)) throw new AssetError("INVALID_ASSET", "Invalid GLB animation channels");
      for (const channel of animation.channels) {
        if (++channelCount > options.limits.maxObjects) throw new AssetError("LIMIT_EXCEEDED", "Animation channel budget exceeded");
        if (!channel?.target || !Number.isSafeInteger(channel.target.node) || !nodes[channel.target.node]
          || !["translation", "rotation", "scale", "weights"].includes(channel.target.path)
          || !Number.isSafeInteger(channel.sampler) || !animation.samplers[channel.sampler])
          throw new AssetError("INVALID_ASSET", "Invalid GLB animation binding");
        const sampler = animation.samplers[channel.sampler], input = accessors[sampler.input], output = accessors[sampler.output];
        const interpolation = sampler.interpolation ?? "LINEAR";
        const type = channel.target.path === "rotation" ? "VEC4" : channel.target.path === "weights" ? "SCALAR" : "VEC3";
        const multiplier = interpolation === "CUBICSPLINE" ? 3 : 1;
        if (!input || !output || input.type !== "SCALAR" || input.componentType !== 5126 || output.componentType !== 5126
          || output.type !== type || !["LINEAR", "STEP", "CUBICSPLINE"].includes(interpolation)
          || output.count < input.count * multiplier || (channel.target.path !== "weights" && output.count !== input.count * multiplier))
          throw new AssetError("INVALID_ASSET", "Invalid GLB animation sampler");
      }
    }
    const manager = new LoadingManager();
    manager.setURLModifier(() => { throw new AssetError("UNSUPPORTED", "Animation inspection attempted an undeclared URL"); });
    const loader = new GLTFLoader(manager);
    for (const name of ["EXT_meshopt_compression", "KHR_meshopt_compression"])
      loader.register(() => ({ name, loadBufferView: async index => contents.views[index]! }));
    loader.register(parser => {
      parser.loadBufferView = async index => {
        checkActive(options.signal);
        const value = contents.views[index];
        if (!value) throw new AssetError("INVALID_ASSET", "Missing animation buffer view");
        return value;
      };
      parser.loadBuffer = async index => {
        const value = contents.buffers[index];
        if (!value) throw new AssetError("INVALID_ASSET", "Missing animation buffer");
        return value;
      };
      // Animation bindings require nodes/skin/morph geometry, not rendered materials.
      parser.loadMaterial = async () => scope.own(new MeshBasicMaterial());
      parser.loadTexture = async () => { throw new AssetError("UNSUPPORTED", "Animation metadata must not decode textures"); };
      const loadGeometries = parser.loadGeometries.bind(parser);
      parser.loadGeometries = async primitives => {
        const geometries = await loadGeometries(primitives);
        geometries.forEach(geometry => scope.own(geometry));
        return geometries;
      };
      const loadMesh = parser.loadMesh.bind(parser);
      parser.loadMesh = async index => {
        const mesh = await loadMesh(index);
        mesh.traverse((object: Object3D) => {
          if (object instanceof Mesh) {
            scope.own(object.geometry);
            for (const material of Array.isArray(object.material) ? object.material : [object.material]) scope.own(material);
            if (object instanceof SkinnedMesh && object.skeleton) scope.own(object.skeleton);
          }
        });
        return mesh;
      };
      return { name: "ELFTIA_animation_metadata" };
    });
    const gltf = await loader.parseAsync(JSON.stringify(contents.json), "");
    checkActive(options.signal);
    if (gltf.animations.length > options.limits.maxObjects) throw new AssetError("LIMIT_EXCEEDED", "Animation clip count exceeds budget");
    let totalKeys = 0, totalTracks = 0;
    const clips = gltf.animations.map((clip, index) => {
      if (!Number.isFinite(clip.duration) || clip.duration < 0) throw new AssetError("INVALID_ASSET", "Invalid animation duration");
      const tracks = clip.tracks.map(track => {
        totalTracks++;
        totalKeys += track.times.length;
        if (totalTracks > options.limits.maxObjects || totalKeys * 4 > options.limits.maxDecodedBytes)
          throw new AssetError("LIMIT_EXCEEDED", "Animation metadata exceeds budget");
        if (!track.validate() || !Number.isSafeInteger(track.getValueSize()) || track.getValueSize() < 1)
          throw new AssetError("INVALID_ASSET", "Invalid animation track");
        for (const values of [track.times, track.values]) for (const value of values)
          if (typeof value === "number" && !Number.isFinite(value)) throw new AssetError("INVALID_ASSET", "Nonfinite animation track");
        for (let key = 1; key < track.times.length; key++)
          if (track.times[key]! <= track.times[key - 1]!) throw new AssetError("INVALID_ASSET", "Animation key times must increase");
        const binding = PropertyBinding.parseTrackName(track.name);
        const node = PropertyBinding.findNode(gltf.scene, binding.nodeName);
        const targetCategory = binding.propertyName === "morphTargetInfluences" ? "morph"
          : ["position", "quaternion", "scale"].includes(binding.propertyName)
            ? node && "isBone" in node && node.isBone ? "bone-transform" : "node-transform" : "other";
        return { name: track.name, type: track.ValueTypeName, valueSize: track.getValueSize(), keyframes: track.times.length, targetCategory };
      });
      return { index, name: clip.name, duration: clip.duration, trackCount: tracks.length, tracks };
    });
    return { value: { version: 1 as const, clips }, dispose: () => scope.dispose() };
  }).then(result => { try { return result.value; } finally { result.dispose(); } });
}
