import { DataTexture, EquirectangularReflectionMapping, FloatType, LinearFilter, LinearSRGBColorSpace, RepeatWrapping, RGBAFormat } from "three";
import { EXRLoader } from "three/addons/loaders/EXRLoader.js";
import { HDRLoader } from "three/addons/loaders/HDRLoader.js";
import { exrDimensions, hdrDimensions } from "./environment-header.js";
import { pmremPixels } from "./environment-pmrem.js";
import { checkActive, ownedLoad, readVerified } from "./ownership.js";
import { AssetError, type AssetDescriptor, type LoadedAsset, type LoadOptions } from "./types.js";

export async function loadEnvironment(asset: AssetDescriptor, options: LoadOptions): Promise<LoadedAsset<DataTexture>> {
  return ownedLoad(options, async (scope) => {
    const bytes = await readVerified(asset, options);
    let dimensions: readonly [number, number];
    let loader: HDRLoader | EXRLoader;
    if (asset.mediaType === "image/vnd.radiance") { dimensions = hdrDimensions(bytes, options); loader = new HDRLoader(); }
    else if (asset.mediaType === "image/x-exr") { dimensions = exrDimensions(bytes, options); loader = new EXRLoader(); }
    else throw new AssetError("UNSUPPORTED", "Environment loader requires HDR or EXR");
    const decoded = loader.setDataType(FloatType).parse(bytes);
    checkActive(options.signal);
    if (!decoded?.data || decoded.width !== dimensions[0] || decoded.height !== dimensions[1] || !(decoded.data instanceof Float32Array) || !(decoded.data.buffer instanceof ArrayBuffer)) throw new AssetError("INVALID_ASSET", "Environment decode failed or dimensions changed");
    const pixels = pmremPixels(decoded.data as Float32Array<ArrayBuffer>, decoded.width, decoded.height, options);
    const value = scope.own(new DataTexture(pixels.data, pixels.width, pixels.height, RGBAFormat, FloatType));
    if (pixels.resized) {
      value.wrapS = RepeatWrapping;
      value.userData.environmentSourceDimensions = [decoded.width, decoded.height];
    }
    value.colorSpace = LinearSRGBColorSpace;
    value.mapping = EquirectangularReflectionMapping;
    value.minFilter = LinearFilter;
    value.magFilter = LinearFilter;
    value.generateMipmaps = false;
    value.flipY = "flipY" in decoded && typeof decoded.flipY === "boolean" ? decoded.flipY : asset.mediaType === "image/vnd.radiance";
    value.needsUpdate = true;
    return { value, dispose: () => scope.dispose() };
  });
}
