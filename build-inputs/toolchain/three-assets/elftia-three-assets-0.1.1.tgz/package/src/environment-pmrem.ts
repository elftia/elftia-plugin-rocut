import { boundedDimensions, checkActive } from "./ownership.js";
import { AssetError, type LoadOptions } from "./types.js";

// r185 PMREM derives face size from equirectangular width / 4, with LOD_MIN=4.
// Smaller inputs decode correctly but produce an atlas that cannot supply IBL.
const MIN_EQUIRECTANGULAR_WIDTH = 64;

export function pmremPixels(
  data: Float32Array<ArrayBuffer>, width: number, height: number, options: LoadOptions,
): { data: Float32Array<ArrayBuffer>; width: number; height: number; resized: boolean } {
  checkActive(options.signal);
  if (width >= MIN_EQUIRECTANGULAR_WIDTH) return { data, width, height, resized: false };
  const outputWidth = MIN_EQUIRECTANGULAR_WIDTH;
  const outputHeight = Math.ceil(height * outputWidth / width);
  boundedDimensions(outputWidth, outputHeight, 16, options);
  // Account for both buffers while resampling, before the new allocation.
  const outputBytes = outputWidth * outputHeight * 16;
  if (data.byteLength + outputBytes > options.limits.maxDecodedBytes) {
    throw new AssetError("LIMIT_EXCEEDED", "Environment normalization exceeds decoded byte budget");
  }
  checkActive(options.signal);
  const output = new Float32Array(outputWidth * outputHeight * 4);
  for (let y = 0; y < outputHeight; y++) {
    checkActive(options.signal);
    const sourceY = (y + 0.5) * height / outputHeight - 0.5;
    const row = Math.floor(sourceY), fy = sourceY - row;
    const y0 = Math.max(0, Math.min(height - 1, row));
    const y1 = Math.max(0, Math.min(height - 1, row + 1));
    for (let x = 0; x < outputWidth; x++) {
      const sourceX = (x + 0.5) * width / outputWidth - 0.5;
      const column = Math.floor(sourceX), fx = sourceX - column;
      const x0 = (column % width + width) % width, x1 = (x0 + 1) % width;
      for (let channel = 0; channel < 4; channel++) {
        const a = data[(y0 * width + x0) * 4 + channel]!;
        const b = data[(y0 * width + x1) * 4 + channel]!;
        const c = data[(y1 * width + x0) * 4 + channel]!;
        const d = data[(y1 * width + x1) * 4 + channel]!;
        output[(y * outputWidth + x) * 4 + channel] =
          (a * (1 - fx) + b * fx) * (1 - fy) + (c * (1 - fx) + d * fx) * fy;
      }
    }
  }
  checkActive(options.signal);
  return { data: output, width: outputWidth, height: outputHeight, resized: true };
}
