import { AssetError, type LoadOptions } from "./types.js";

export type JsonRecord = Record<string, unknown>;
export function record(value: unknown): JsonRecord {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new AssetError("INVALID_ASSET", "Expected glTF object");
  return value as JsonRecord;
}
export function list(value: unknown): unknown[] {
  if (value === undefined) return [];
  if (!Array.isArray(value)) throw new AssetError("INVALID_ASSET", "Expected glTF array");
  return value;
}
export function integer(value: unknown, maximum: number, minimum = 0): number {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < minimum || value > maximum) throw new AssetError("INVALID_ASSET", "Invalid glTF integer or out-of-range reference");
  return value;
}

const supportedExtensions = new Set([
  "KHR_materials_unlit", "KHR_materials_clearcoat", "KHR_materials_transmission", "KHR_materials_volume",
  "KHR_materials_ior", "KHR_materials_specular", "KHR_materials_sheen", "KHR_materials_iridescence",
  "KHR_materials_anisotropy", "KHR_materials_emissive_strength", "KHR_materials_dispersion",
  "KHR_texture_transform", "KHR_mesh_quantization", "KHR_lights_punctual", "EXT_texture_webp",
  "EXT_meshopt_compression", "KHR_meshopt_compression", "KHR_draco_mesh_compression", "KHR_texture_basisu",
]);
const forbiddenDecoders = new Set(["EXT_mesh_gpu_instancing"]);

export function validateJson(json: JsonRecord, options: LoadOptions): void {
  const asset = record(json.asset);
  if (asset.version !== "2.0" || (asset.minVersion !== undefined && asset.minVersion !== "2.0")) throw new AssetError("UNSUPPORTED", "Only glTF 2.0 is supported");
  for (const name of list(json.extensionsRequired)) {
    if (typeof name !== "string" || !supportedExtensions.has(name)) throw new AssetError("UNSUPPORTED", `Unsupported required glTF extension: ${String(name)}`);
  }
  const stack: { value: unknown; depth: number }[] = [{ value: json, depth: 0 }];
  const meshoptLocations = new Set([...list(json.buffers), ...list(json.bufferViews)]);
  const dracoLocations = new Set(list(json.meshes).flatMap(mesh => list(record(mesh).primitives)));
  const basisLocations = new Set(list(json.textures));
  let count = 0;
  while (stack.length) {
    const { value, depth } = stack.pop()!;
    if (++count > options.limits.maxObjects || depth > 128) throw new AssetError("LIMIT_EXCEEDED", "glTF object count or depth exceeds limits");
    if (!value || typeof value !== "object") continue;
    if (!Array.isArray(value)) {
      for (const name of Object.keys((value as JsonRecord).extensions ?? {})) {
        if (forbiddenDecoders.has(name)) throw new AssetError("UNSUPPORTED", `glTF extension is not enabled: ${name}`);
        if (name === "KHR_draco_mesh_compression" && !dracoLocations.has(value)) throw new AssetError("INVALID_ASSET", "Draco extension must belong to a primitive");
        if (name === "KHR_texture_basisu" && !basisLocations.has(value)) throw new AssetError("INVALID_ASSET", "Basis extension must belong to a texture");
        if ((name === "EXT_meshopt_compression" || name === "KHR_meshopt_compression") && !meshoptLocations.has(value)) throw new AssetError("INVALID_ASSET", "Meshopt extension must belong to a buffer/view");
      }
    }
    for (const child of Object.values(value)) stack.push({ value: child, depth: depth + 1 });
  }
  for (const name of list(json.extensionsUsed)) {
    if (typeof name !== "string" || forbiddenDecoders.has(name)) throw new AssetError("UNSUPPORTED", `glTF extension is not enabled: ${String(name)}`);
  }
  validateNodes(json, options.limits.maxObjects);
}

function validateNodes(json: JsonRecord, maximum: number): void {
  const nodes = list(json.nodes).map(record);
  const parents = new Set<number>();
  const children = nodes.map((node) => list(node.children).map((child) => integer(child, nodes.length - 1)));
  for (const group of children) for (const child of group) {
    if (parents.has(child)) throw new AssetError("INVALID_ASSET", "glTF node has multiple parents");
    parents.add(child);
  }
  const finished = new Set<number>();
  const visit = (index: number, path: Set<number>): void => {
    if (path.has(index)) throw new AssetError("INVALID_ASSET", "Cyclic glTF node hierarchy");
    if (path.size > 128) throw new AssetError("LIMIT_EXCEEDED", "glTF node hierarchy exceeds depth limit");
    if (finished.has(index)) return;
    path.add(index);
    for (const child of children[index]!) visit(child, path);
    path.delete(index);
    finished.add(index);
  };
  nodes.forEach((_, index) => visit(index, new Set()));
  const scenes = list(json.scenes);
  if (Math.max(1, scenes.length) * nodes.length > maximum) throw new AssetError("LIMIT_EXCEEDED", "glTF scene expansion exceeds object limit");
  for (const scene of scenes) for (const index of list(record(scene).nodes)) integer(index, nodes.length - 1);
}

export function validateAccessors(json: JsonRecord, views: readonly { readonly byteLength: number }[], options: LoadOptions, inspectSparse = true): number {
  const sizes: Record<string, number> = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4, MAT2: 4, MAT3: 9, MAT4: 16 };
  const components: Record<string, number> = { "5120": 1, "5121": 1, "5122": 2, "5123": 2, "5125": 4, "5126": 4 };
  const definitions = list(json.bufferViews).map(record);
  let allocated = 0;
  const range = (index: unknown, offset: unknown, length: number): void => {
    const view = views[integer(index, views.length - 1)]!;
    const start = integer(offset ?? 0, view.byteLength);
    if (start + length > view.byteLength) throw new AssetError("INVALID_ASSET", "glTF accessor exceeds buffer view");
  };
  for (const raw of list(json.accessors)) {
    const accessor = record(raw);
    const width = sizes[String(accessor.type)];
    const component = components[String(accessor.componentType)];
    if (!width || !component) throw new AssetError("INVALID_ASSET", "Invalid glTF accessor format");
    const count = integer(accessor.count, options.limits.maxDecodedBytes, 1);
    const columns = accessor.type === "MAT2" ? 2 : accessor.type === "MAT3" ? 3 : accessor.type === "MAT4" ? 4 : 0;
    const elementBytes = columns ? columns * Math.ceil(columns * component / 4) * 4 : width * component;
    const bytes = count * width * Math.max(4, component);
    allocated += bytes * 2; // Includes sparse expansion and animation/morph copies.
    if (allocated > options.limits.maxDecodedBytes) throw new AssetError("LIMIT_EXCEEDED", "glTF decoded buffers exceed limits");
    if (accessor.bufferView !== undefined) {
      const index = integer(accessor.bufferView, views.length - 1);
      const stride = integer(definitions[index]!.byteStride ?? elementBytes, 252, elementBytes);
      if (stride % component || integer(accessor.byteOffset ?? 0, views[index]!.byteLength) % component) throw new AssetError("INVALID_ASSET", "Misaligned glTF accessor");
      range(index, accessor.byteOffset, (count - 1) * stride + elementBytes);
    }
    if (accessor.sparse !== undefined) {
      const sparse = record(accessor.sparse);
      const length = integer(sparse.count, count, 1);
      const indices = record(sparse.indices);
      const values = record(sparse.values);
      const indexSize = components[String(indices.componentType)];
      if (![5121, 5123, 5125].includes(Number(indices.componentType)) || !indexSize) throw new AssetError("INVALID_ASSET", "Invalid sparse index type");
      range(indices.bufferView, indices.byteOffset, length * indexSize);
      range(values.bufferView, values.byteOffset, length * elementBytes);
      const indexView = integer(indices.bufferView, views.length - 1), valueView = integer(values.bufferView, views.length - 1);
      if (definitions[indexView]!.byteStride !== undefined || definitions[valueView]!.byteStride !== undefined || definitions[indexView]!.target !== undefined || definitions[valueView]!.target !== undefined) throw new AssetError("INVALID_ASSET", "Sparse buffer views cannot be interleaved or have targets");
      if (integer(indices.byteOffset ?? 0, views[indexView]!.byteLength) % indexSize || integer(values.byteOffset ?? 0, views[valueView]!.byteLength) % component) throw new AssetError("INVALID_ASSET", "Misaligned sparse accessor");
      const bytes = views[integer(indices.bufferView, views.length - 1)]!;
      if (!(bytes instanceof ArrayBuffer)) {
        if (!inspectSparse) continue;
        throw new AssetError("INVALID_ASSET", "Sparse bytes unavailable");
      }
      const data = new DataView(bytes);
      const offset = integer(indices.byteOffset ?? 0, data.byteLength);
      let previous = -1;
      for (let i = 0; i < length; i++) {
        const position = offset + i * indexSize;
        const value = indexSize === 1 ? data.getUint8(position) : indexSize === 2 ? data.getUint16(position, true) : data.getUint32(position, true);
        if (value <= previous || value >= count) throw new AssetError("INVALID_ASSET", "Sparse indices must be ordered and in range");
        previous = value;
      }
    }
  }
  return allocated;
}
