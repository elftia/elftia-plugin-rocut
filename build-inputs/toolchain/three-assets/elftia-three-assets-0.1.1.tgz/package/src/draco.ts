import { integer, list, record, type JsonRecord } from "./glb-validation.js";
import { checkActive } from "./ownership.js";
import { AssetError, type LoadOptions } from "./types.js";

const name = "KHR_draco_mesh_compression";
const formats = { 5120: [Int8Array, "DT_INT8"], 5121: [Uint8Array, "DT_UINT8"], 5122: [Int16Array, "DT_INT16"], 5123: [Uint16Array, "DT_UINT16"], 5125: [Uint32Array, "DT_UINT32"], 5126: [Float32Array, "DT_FLOAT32"] } as const;
interface AttributePlan { accessor: JsonRecord; id: number; width: number; count: number; component: keyof typeof formats }
export interface DracoPlan { primitive: JsonRecord; view: number; attributes: AttributePlan[]; indices: JsonRecord; count: number }

export function planDraco(json: JsonRecord, options: LoadOptions, account: (bytes: number) => void): DracoPlan[] {
  const accessors = list(json.accessors).map(record), views = list(json.bufferViews).map(record);
  const plans: DracoPlan[] = [];
  const claimed = new Set<JsonRecord>();
  for (const mesh of list(json.meshes).map(record)) for (const primitive of list(mesh.primitives).map(record)) {
    const extension = primitive.extensions === undefined ? undefined : record(primitive.extensions)[name];
    if (extension === undefined) continue;
    if (!list(json.extensionsUsed).includes(name)) throw new AssetError("INVALID_ASSET", "Draco extension is undeclared");
    const def = record(extension);
    if (Object.keys(def).some(key => key !== "bufferView" && key !== "attributes")) throw new AssetError("INVALID_ASSET", "Unsupported Draco field");
    if ((primitive.mode ?? 4) !== 4) throw new AssetError("UNSUPPORTED", "Draco requires triangle primitives");
    const view = integer(def.bufferView, views.length - 1);
    if (views[view]!.byteStride !== undefined || record(views[view]!.extensions ?? {}) .EXT_meshopt_compression || record(views[view]!.extensions ?? {}).KHR_meshopt_compression) throw new AssetError("INVALID_ASSET", "Ambiguous Draco source layout");
    const mapping = record(def.attributes), attributes = record(primitive.attributes), ids = new Set<number>();
    if (mapping.POSITION === undefined) throw new AssetError("INVALID_ASSET", "Draco POSITION is required");
    const output: AttributePlan[] = [];
    for (const [semantic, value] of Object.entries(mapping)) {
      const id = integer(value, 65535);
      if (ids.has(id)) throw new AssetError("INVALID_ASSET", "Duplicate Draco attribute ID");
      ids.add(id);
      const accessor = accessors[integer(attributes[semantic], accessors.length - 1)]!;
      const width = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4 }[String(accessor.type)];
      const component = Number(accessor.componentType) as keyof typeof formats;
      if (!width || !formats[component] || accessor.sparse !== undefined || (accessor.byteOffset ?? 0) !== 0 || claimed.has(accessor)) throw new AssetError("INVALID_ASSET", "Invalid or shared Draco accessor");
      const expected = semantic === "POSITION" || semantic === "NORMAL" ? [3] : semantic === "TANGENT" || /^(JOINTS|WEIGHTS)_\d+$/u.test(semantic) ? [4] : /^TEXCOORD_\d+$/u.test(semantic) ? [2] : /^COLOR_\d+$/u.test(semantic) ? [3,4] : undefined;
      if (expected && !expected.includes(width) || accessor.normalized !== undefined && typeof accessor.normalized !== "boolean" || accessor.normalized === true && component === 5126) throw new AssetError("INVALID_ASSET", "Invalid Draco attribute semantic format");
      claimed.add(accessor);
      const count = integer(accessor.count, options.limits.maxDecodedBytes, 1);
      account(count * width * 12);
      output.push({ accessor, id, width, count, component });
    }
    const count = output[0]!.count;
    if (output.some(attribute => attribute.count !== count)) throw new AssetError("INVALID_ASSET", "Draco attribute counts disagree");
    for (const value of Object.values(attributes)) if (accessors[integer(value, accessors.length - 1)]!.count !== count) throw new AssetError("INVALID_ASSET", "Draco primitive attribute counts disagree");
    const indices = accessors[integer(primitive.indices, accessors.length - 1)]!;
    if (claimed.has(indices) || indices.type !== "SCALAR" || ![5121, 5123, 5125].includes(Number(indices.componentType)) || indices.sparse !== undefined || (indices.byteOffset ?? 0) !== 0) throw new AssetError("INVALID_ASSET", "Invalid Draco index accessor");
    claimed.add(indices);
    const indexCount = integer(indices.count, options.limits.maxDecodedBytes, 3);
    if (indexCount % 3) throw new AssetError("INVALID_ASSET", "Draco index count is not triangular");
    account(indexCount * 12 + integer(views[view]!.byteLength, options.limits.maxBytes, 1) * 2);
    plans.push({ primitive, view, attributes: output, indices, count });
  }
  const references = new Map<JsonRecord, number>();
  for (const mesh of list(json.meshes).map(record)) for (const primitive of list(mesh.primitives).map(record)) {
    const indices = primitive.indices === undefined ? [] : [primitive.indices];
    for (const value of [...Object.values(record(primitive.attributes)), ...indices, ...list(primitive.targets).flatMap(target => Object.values(record(target)))]) {
      const accessor = accessors[integer(value, accessors.length - 1)]!;
      references.set(accessor, (references.get(accessor) ?? 0) + 1);
    }
  }
  for (const accessor of claimed) if (references.get(accessor) !== 1) throw new AssetError("INVALID_ASSET", "Draco accessors cannot be shared by primitive references");
  if (!plans.length && [...list(json.extensionsUsed), ...list(json.extensionsRequired)].includes(name)) {
    throw new AssetError("INVALID_ASSET", "Declared Draco extension has no primitive");
  }
  if (plans.length) account(1024 * 1024 + 65536);
  return plans;
}

/** Decode completely before replacing any JSON definition visible to the parser. */
export async function decodeDraco(plans: DracoPlan[], json: JsonRecord, views: ArrayBuffer[], options: LoadOptions): Promise<void> {
  if (!plans.length) return;
  checkActive(options.signal);
  const { default: factory } = await import("./draco-decoder.js");
  const scratch = 1024 * 1024 + plans.reduce((total, plan) => total + plan.attributes.reduce((bytes, item) => bytes + item.count * item.width * 8, 0) + Number(plan.indices.count) * 8 + views[plan.view]!.byteLength * 2, 0);
  const pages = Math.ceil(scratch / 65536);
  if (scratch > Math.min(options.limits.maxDecodedBytes, 64 * 1024 * 1024)) throw new AssetError("LIMIT_EXCEEDED", "Draco scratch budget exceeded");
  const memory = new WebAssembly.Memory({ initial: 16, maximum: pages });
  const draco = await factory({ wasmMemory: memory });
  checkActive(options.signal);
  const replacements: { accessor: JsonRecord; bytes: ArrayBuffer }[] = [];
  try {
    for (const plan of plans) {
      checkActive(options.signal);
      const decoder = new draco.Decoder(), buffer = new draco.DecoderBuffer(), mesh = new draco.Mesh();
      let status;
      try {
        const source = new Int8Array(views[plan.view]!);
        buffer.Init(source, source.length);
        if (decoder.GetEncodedGeometryType(buffer) !== draco.TRIANGULAR_MESH) throw new Error("Expected Draco triangle mesh");
        status = decoder.DecodeBufferToMesh(buffer, mesh);
        if (!status.ok() || !mesh.ptr || mesh.num_points() !== plan.count || mesh.num_faces() * 3 !== plan.indices.count) throw new Error("Draco decoded counts disagree with accessors");
        const extract = (length: number, component: keyof typeof formats, operation: (ptr: number, bytes: number) => boolean): ArrayBuffer => {
          const Type = formats[component][0], byteLength = length * Type.BYTES_PER_ELEMENT;
          const ptr = draco._malloc(byteLength);
          if (!ptr) throw new Error("Draco scratch allocation failed");
          try {
            if (!operation(ptr, byteLength)) throw new Error("Draco extraction failed");
            return new Type(draco.HEAPU8.buffer, ptr, length).slice().buffer as ArrayBuffer;
          } finally { draco._free(ptr); }
        };
        for (const item of plan.attributes) {
          const attribute = decoder.GetAttributeByUniqueId(mesh, item.id);
          if (!attribute.ptr || attribute.num_components() !== item.width) throw new Error("Draco attribute layout mismatch");
          const bytes = extract(item.count * item.width, item.component, (ptr, size) => decoder.GetAttributeDataArrayForAllPoints(mesh, attribute, draco[formats[item.component][1]], size, ptr));
          if (item.component === 5126 && Array.from(new Float32Array(bytes)).some(value => !Number.isFinite(value))) throw new Error("Nonfinite Draco attribute");
          replacements.push({ accessor: item.accessor, bytes });
        }
        const indexBytes = extract(Number(plan.indices.count), 5125, (ptr, size) => decoder.GetTrianglesUInt32Array(mesh, size, ptr));
        const indices = new Uint32Array(indexBytes), component = Number(plan.indices.componentType) as 5121 | 5123 | 5125;
        const maximum = component === 5121 ? 255 : component === 5123 ? 65535 : 4294967295;
        if (indices.some(index => index >= plan.count || index > maximum)) throw new Error("Draco index is out of range");
        replacements.push({ accessor: plan.indices, bytes: new formats[component][0](indices).buffer });
      } finally {
        if (status) draco.destroy(status);
        draco.destroy(mesh); draco.destroy(buffer); draco.destroy(decoder);
      }
    }
    checkActive(options.signal);
    const definitions = list(json.bufferViews);
    for (const replacement of replacements) {
      replacement.accessor.bufferView = views.length;
      replacement.accessor.byteOffset = 0;
      definitions.push({ buffer: 0, byteLength: replacement.bytes.byteLength });
      views.push(replacement.bytes);
    }
    json.bufferViews = definitions;
    for (const plan of plans) delete record(plan.primitive.extensions)[name];
    for (const key of ["extensionsUsed", "extensionsRequired"]) json[key] = list(json[key]).filter(value => value !== name);
  } catch (error) {
    checkActive(options.signal);
    throw new AssetError("INVALID_ASSET", `Draco decode failed: ${error instanceof Error ? error.message : "invalid stream"}`);
  }
}
