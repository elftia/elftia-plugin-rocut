import { AssetError } from "./types.js";
import { exrBlockHeights, validateExrPayload } from "./exr-codecs.js";

export function validateExrBlocks(buffer: ArrayBuffer, table: number, width: number, height: number, yMin: number, channelSizes: readonly number[], compression: number): void {
  const data = new DataView(buffer);
  const bytes = new Uint8Array(buffer);
  const fail = (): never => { throw new AssetError("INVALID_ASSET", "Malformed EXR scanline block"); };
  const blockHeight = exrBlockHeights[compression];
  if (!blockHeight) throw new AssetError("UNSUPPORTED", "Unknown EXR compression");
  const blocks = Math.ceil(height / blockHeight);
  let position = table + blocks * 8;
  if (position > bytes.length) return fail();
  const offsets = new Set<number>();
  for (let block = 0; block < blocks; block++) {
    const value = Number(data.getBigUint64(table + block * 8, true));
    if (!Number.isSafeInteger(value) || value < position || value + 8 > bytes.length || offsets.has(value)) return fail();
    offsets.add(value);
  }
  const rows = new Set<number>();
  for (let block = 0; block < blocks; block++) {
    if (!offsets.has(position) || position + 8 > bytes.length) return fail();
    const row = data.getInt32(position, true) - yMin;
    if (row < 0 || row >= height || row % blockHeight || rows.has(row)) return fail();
    rows.add(row);
    const lines = Math.min(blockHeight, height - row);
    const length = data.getUint32(position + 4, true);
    if (!length || position + 8 + length > bytes.length) return fail();
    const chunk = bytes.subarray(position + 8, position + 8 + length);
    validateExrPayload(chunk, width, lines, channelSizes, compression);
    position += 8 + length;
  }
  if (position !== bytes.length) return fail();
}
