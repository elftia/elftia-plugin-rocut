import { AnimationMixer, LoopOnce, SkinnedMesh } from "three";
import { AssetError, type ModelInstance } from "./types.js";

export interface ModelAnimationOptions {
  /** Exact, unique clip name or zero-based clip index. */
  readonly clip: string | number;
  readonly mode?: "loop" | "clamp";
  /** Clip seconds per absolute second; zero and negative speeds are supported. */
  readonly speed?: number;
  /** Clip-time offset in seconds: absoluteSeconds * speed + offset. */
  readonly offset?: number;
}

export interface ModelAnimationController {
  readonly clipIndex: number;
  readonly clipName: string;
  readonly duration: number;
  /** Applies an absolute time and returns the sampled clip time. No clock is started. */
  seek(absoluteSeconds: number): number;
  /** Restores bound properties and releases the mixer, retaining the caller's instance. */
  dispose(): void;
}

/**
 * Owns animation bindings only. Dispose this controller before disposing its ModelInstance.
 * Use one controller per instance; other mixers must not animate the same properties.
 */
export function createModelAnimation(instance: ModelInstance, options: ModelAnimationOptions): ModelAnimationController {
  const { clip: selection, mode = "loop", speed = 1, offset = 0 } = options;
  if ((mode !== "loop" && mode !== "clamp") || !Number.isFinite(speed) || !Number.isFinite(offset)) {
    throw new AssetError("INVALID_ASSET", "Animation mode, speed or offset is invalid");
  }
  let clipIndex: number;
  if (typeof selection === "number") {
    clipIndex = selection;
    if (!Number.isInteger(clipIndex) || clipIndex < 0 || clipIndex >= instance.animations.length) {
      throw new AssetError("INVALID_ASSET", "Animation clip index is out of range");
    }
  } else {
    const matches = instance.animations.map((clip, index) => clip.name === selection ? index : -1).filter((index) => index !== -1);
    if (matches.length !== 1) throw new AssetError("INVALID_ASSET", "Animation clip name must identify exactly one clip");
    clipIndex = matches[0]!;
  }
  const clip = instance.animations[clipIndex]!;
  if (!Number.isFinite(clip.duration) || clip.duration < 0) {
    throw new AssetError("INVALID_ASSET", "Animation clip duration is invalid");
  }
  const mixer = new AnimationMixer(instance.value);
  const action = mixer.clipAction(clip);
  action.setLoop(LoopOnce, 1);
  action.clampWhenFinished = true;
  let disposed = false;
  let started = false;
  const updatePose = (): void => {
    instance.value.updateMatrixWorld(true);
    instance.value.traverse((object) => { if (object instanceof SkinnedMesh) object.skeleton.update(); });
  };
  return {
    clipIndex, clipName: clip.name, duration: clip.duration,
    seek(absoluteSeconds) {
      if (disposed) throw new AssetError("DISPOSED", "Animation controller has been disposed");
      const time = absoluteSeconds * speed + offset;
      if (!Number.isFinite(absoluteSeconds) || !Number.isFinite(time)) {
        throw new AssetError("INVALID_ASSET", "Animation time must be finite");
      }
      const sampledTime = clip.duration === 0 ? 0 : mode === "clamp"
        ? Math.min(clip.duration, Math.max(0, time))
        : ((time % clip.duration) + clip.duration) % clip.duration;
      if (!started) { action.play(); started = true; }
      // Zero-delta evaluation keeps loop counters and finished events out of absolute seeking.
      action.time = sampledTime;
      mixer.update(0);
      updatePose();
      return sampledTime;
    },
    dispose() {
      if (disposed) return;
      disposed = true;
      mixer.stopAllAction();
      mixer.uncacheRoot(instance.value);
      if (started) updatePose();
    },
  };
}
