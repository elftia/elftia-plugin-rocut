// HDRLoader is the Three 0.185 name for the RGBE loader. Keep builds compatible
// with declaration bundles that still expose only the previous RGBELoader name.
declare module "three/addons/loaders/HDRLoader.js" {
  export { RGBELoader as HDRLoader } from "three/addons/loaders/RGBELoader.js";
}
