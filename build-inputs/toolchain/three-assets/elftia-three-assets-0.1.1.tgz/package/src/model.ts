import { Group, Line, LoadingManager, Material, Mesh, Points, SkinnedMesh, Texture, type Object3D } from "three";
import { GLTFLoader, type GLTFParser } from "three/addons/loaders/GLTFLoader.js";
import { inspectGlb } from "./glb.js";
import { decodeTexture } from "./image.js";
import { decodeKtx2Texture } from "./ktx2.js";
import { modelHandle } from "./model-instance.js";
import { checkActive, ownedLoad, readVerified, type ResourceScope } from "./ownership.js";
import { AssetError, type AssetDescriptor, type LoadedModel, type LoadOptions } from "./types.js";

function trackParser(parser: GLTFParser, scope: ResourceScope): void {
  const material = (value: Material): void => {
    scope.own(value);
    for (const item of Object.values(value)) if (item instanceof Texture) scope.own(item);
  };
  const object = (root: Object3D): void => root.traverse((value) => {
    if (value instanceof Mesh || value instanceof Line || value instanceof Points) {
      scope.own(value.geometry);
      for (const item of Array.isArray(value.material) ? value.material : [value.material]) material(item);
      if (value instanceof SkinnedMesh && value.skeleton) scope.own(value.skeleton);
    }
  });
  const loadMaterial = parser.loadMaterial.bind(parser);
  parser.loadMaterial = async (index) => { const value = await loadMaterial(index); material(value); return value; };
  const loadGeometries = parser.loadGeometries.bind(parser);
  parser.loadGeometries = async (primitives) => (await Promise.all(primitives.map(async (primitive) => {
    const values = await loadGeometries([primitive]);
    values.forEach((value) => scope.own(value));
    return values;
  }))).flat();
  const assignTexture = parser.assignTexture.bind(parser);
  parser.assignTexture = async (...args) => { const value = await assignTexture(...args); if (value) scope.own(value); return value; };
  const assignFinalMaterial = parser.assignFinalMaterial.bind(parser);
  parser.assignFinalMaterial = (mesh) => { assignFinalMaterial(mesh); object(mesh); };
  const loadMesh = parser.loadMesh.bind(parser);
  parser.loadMesh = async (index) => { const value = await loadMesh(index); object(value); return value; };
  const loadSkin = parser.loadSkin.bind(parser);
  parser.loadSkin = async (index) => scope.own(await loadSkin(index));
}

export async function loadModel(asset: AssetDescriptor, options: LoadOptions): Promise<LoadedModel> {
  return ownedLoad(options, async (scope) => {
    if (asset.mediaType !== "model/gltf-binary") throw new AssetError("UNSUPPORTED", "Model loader requires a self-contained GLB");
    const bytes = await readVerified(asset, options);
    const contents = await inspectGlb(bytes, options);
    scope.onDispose(() => { contents.views.length = 0; contents.buffers.length = 0; contents.images.length = 0; });
    checkActive(options.signal);
    // Predecode all images: GLTFLoader otherwise catches decode errors and returns null maps.
    const images = await Promise.all(contents.images.map((image) => image.mediaType === "image/ktx2"
      ? decodeKtx2Texture(image.bytes, options, scope)
      : decodeTexture(image.bytes, image.mediaType, false, options, scope)));
    checkActive(options.signal);
    const manager = new LoadingManager();
    manager.setURLModifier(() => { throw new AssetError("UNSUPPORTED", "GLB attempted an undeclared URL request"); });
    const loader = new GLTFLoader(manager);
    // Built-in codec plugins run before parser.loadBufferView. Replace both names
    // with fixed already-decoded views so they cannot decode or use fallback again.
    for (const name of ["EXT_meshopt_compression", "KHR_meshopt_compression"]) {
      loader.register(() => ({ name, loadBufferView: async (index) => {
        checkActive(options.signal);
        const value = contents.views[index];
        if (!value) throw new AssetError("INVALID_ASSET", "Missing GLB buffer view");
        return value;
      } }));
    }
    loader.register((parser) => {
      // Use only the preflighted/predecoded fixed local views, including Meshopt.
      // GLTFLoader never chooses an author decoder or allocates a fallback buffer.
      parser.loadBufferView = async (index) => {
        checkActive(options.signal);
        const value = contents.views[index];
        if (!value) throw new AssetError("INVALID_ASSET", "Missing GLB buffer view");
        return value;
      };
      parser.loadBuffer = async (index) => {
        const value = contents.buffers[index];
        if (!value) throw new AssetError("INVALID_ASSET", "Missing GLB buffer");
        return value;
      };
      parser.loadImageSource = async (index) => {
        const value = images[index];
        if (!value) throw new AssetError("INVALID_ASSET", "Missing GLB image");
        return scope.own(value.clone());
      };
      const loadTextureImage = parser.loadTextureImage.bind(parser);
      parser.loadTextureImage = async (...args) => {
        const value = await loadTextureImage(...args);
        if (!value) throw new AssetError("INVALID_ASSET", "GLB texture could not be loaded");
        return scope.own(value);
      };
      trackParser(parser, scope);
      return { name: "ELFTIA_owned_resources" };
    });
    const gltf = await loader.parseAsync(JSON.stringify(contents.json), "");
    checkActive(options.signal);
    if (!(gltf.scene instanceof Group)) throw new AssetError("INVALID_ASSET", "GLB has no default scene");
    return modelHandle(gltf, scope);
  });
}
