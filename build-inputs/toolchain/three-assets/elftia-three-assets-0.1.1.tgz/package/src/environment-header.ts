import { boundedDimensions } from "./ownership.js";
import { validateExrBlocks } from "./exr-blocks.js";
import { validateExrTiles, type ExrTiles } from "./exr-tiles.js";
import { validateExrAttribute } from "./exr-attributes.js";
import { AssetError, type LoadOptions } from "./types.js";

export function hdrDimensions(bytes: ArrayBuffer, options: LoadOptions): readonly [number, number] {
  const header = new TextDecoder().decode(bytes.slice(0, 16384));
  const match = /^-Y (\d+) \+X (\d+)\r?$/mu.exec(header);
  if (!/^#\?(RADIANCE|RGBE)\r?\n/u.test(header) || !header.includes("FORMAT=32-bit_rle_rgbe") || !match) throw new AssetError("INVALID_ASSET", "Invalid or unsupported Radiance header");
  const width = Number(match[2]);
  const height = Number(match[1]);
  boundedDimensions(width, height, 16, options);
  return [width, height];
}

/** Bound the header before Three's null-terminated string readers and allocation. */
export function exrDimensions(buffer: ArrayBuffer, options: LoadOptions): readonly [number, number] {
  const data = new DataView(buffer);
  const bytes = new Uint8Array(buffer);
  const invalid = (): never => { throw new AssetError("INVALID_ASSET", "Malformed EXR header"); };
  if (data.byteLength < 9 || data.getUint32(0, true) !== 20000630) return invalid();
  const version = data.getUint32(4, true);
  // Deep/multipart were not supported by Director's r170 decoder and need separate policies.
  if ((version & 255) !== 2 || (version & ~0x602) !== 0) throw new AssetError("UNSUPPORTED", "Deep or multipart EXR requires a separate resource policy");
  let offset = 8;
  const string = (end: number): string => {
    const start = offset;
    while (offset < end && bytes[offset] !== 0 && offset - start <= 255) offset++;
    if (offset >= end || offset - start > 255) return invalid();
    return new TextDecoder("utf-8", { fatal: true }).decode(bytes.subarray(start, offset++));
  };
  const seen = new Set<string>();
  let width = 0;
  let height = 0;
  let yMin = 0;
  let channelBytes = 0;
  const channelSizes: number[] = [];
  let tiles: ExrTiles | undefined;
  let compression = -1;
  while (offset < bytes.length && bytes[offset] !== 0) {
    if (offset > 65536 || seen.size > 128) throw new AssetError("LIMIT_EXCEEDED", "EXR header exceeds limits");
    const name = string(bytes.length);
    const type = string(bytes.length);
    if (seen.has(name) || offset + 4 > bytes.length) return invalid();
    seen.add(name);
    const length = data.getUint32(offset, true);
    offset += 4;
    const end = offset + length;
    if (end > bytes.length || end > 65536) return invalid();
    const sizes = validateExrAttribute(bytes, type, offset, end, name === "channels");
    if (name === "dataWindow") {
      if (type !== "box2i" || length !== 16) return invalid();
      width = data.getInt32(offset + 8, true) - data.getInt32(offset, true) + 1;
      yMin = data.getInt32(offset + 4, true);
      height = data.getInt32(offset + 12, true) - yMin + 1;
    } else if (name === "compression") {
      if (type !== "compression" || length !== 1) return invalid();
      compression = bytes[offset]!;
    } else if (name === "tiles") {
      if (type !== "tiledesc" || length !== 9) return invalid();
      tiles = { width: data.getUint32(offset, true), height: data.getUint32(offset + 4, true), mode: bytes[offset + 8]! };
    } else if (name === "channels") {
      if (type !== "chlist") return invalid();
      channelSizes.push(...sizes);
      channelBytes = sizes.reduce((sum, size) => sum + size, 0);
    }
    offset = end;
  }
  if (offset >= bytes.length || !seen.has("channels") || !seen.has("dataWindow") || compression < 0) return invalid();
  if (compression > 9) throw new AssetError("UNSUPPORTED", "Unknown EXR compression");
  boundedDimensions(width, height, Math.max(16, channelBytes * Math.max(2, channelSizes.length)), options);
  if ((version & 0x200) !== 0) {
    if (!tiles) return invalid();
    validateExrTiles(buffer, offset + 1, width, height, channelSizes, compression, tiles, options.limits.maxObjects);
  } else validateExrBlocks(buffer, offset + 1, width, height, yMin, channelSizes, compression);
  return [width, height];
}
