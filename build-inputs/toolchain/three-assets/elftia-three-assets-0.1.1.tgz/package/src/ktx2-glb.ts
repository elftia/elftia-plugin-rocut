import { integer, list, record, type JsonRecord } from "./glb-validation.js";
import { AssetError } from "./types.js";

/** Select the admitted Basis image, not an optional PNG fallback or author decoder. */
export function normalizeBasisuTextures(json: JsonRecord, images: readonly { mediaType: string }[]): void {
  const name = "KHR_texture_basisu";
  let count = 0;
  for (const raw of list(json.textures)) {
    const texture = record(raw);
    if (texture.extensions === undefined) continue;
    const extensions = record(texture.extensions);
    if (extensions[name] === undefined) continue;
    if (!list(json.extensionsUsed).includes(name)) throw new AssetError("INVALID_ASSET", "Basis texture extension is not declared");
    const source = integer(record(extensions[name]).source, images.length - 1);
    if (images[source]!.mediaType !== "image/ktx2") throw new AssetError("INVALID_ASSET", "Basis texture requires an embedded KTX2 image");
    texture.source = source;
    delete extensions[name];
    count++;
  }
  if (!count && [...list(json.extensionsUsed), ...list(json.extensionsRequired)].includes(name)) {
    throw new AssetError("INVALID_ASSET", "Declared Basis texture extension has no texture");
  }
  for (const key of ["extensionsUsed", "extensionsRequired"]) {
    if (json[key] !== undefined) json[key] = list(json[key]).filter(value => value !== name);
  }
}
