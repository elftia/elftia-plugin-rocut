import { malformedExr } from "./exr-compression.js";
import { AssetError } from "./types.js";

const fixedSizes: Readonly<Record<string, number>> = {
  chromaticities: 32, compression: 1, box2i: 16, envmap: 1, tiledesc: 9,
  lineOrder: 1, float: 4, v2f: 8, v3f: 12, int: 4, rational: 8, timecode: 8,
};

/** Three dispatches by type even for custom names; validate every recognized payload. */
export function validateExrAttribute(bytes: Uint8Array, type: string, start: number, end: number, imageChannels: boolean): number[] {
  if (Object.hasOwn(fixedSizes, type) && end - start !== fixedSizes[type]) malformedExr("attribute size");
  if (type !== "chlist") return [];
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const names = new Set<string>();
  const sizes: number[] = [];
  let offset = start;
  while (offset < end && bytes[offset] !== 0) {
    const nameStart = offset;
    while (offset < end && bytes[offset] !== 0 && offset - nameStart <= 255) {
      if (bytes[offset]! > 127) malformedExr("channel name encoding");
      offset++;
    }
    if (offset >= end || offset - nameStart > 255 || offset + 17 > end) malformedExr("channel attribute bounds");
    const name = new TextDecoder().decode(bytes.subarray(nameStart, offset++));
    if (names.has(name) || names.size >= 16) malformedExr("duplicate or excessive channels");
    names.add(name);
    const pixelType = view.getInt32(offset, true);
    if (imageChannels && ((pixelType !== 1 && pixelType !== 2) || view.getInt32(offset + 8, true) !== 1 || view.getInt32(offset + 12, true) !== 1)) {
      throw new AssetError("UNSUPPORTED", "EXR requires HALF/FLOAT channels without subsampling");
    }
    sizes.push(pixelType === 1 ? 2 : 4);
    offset += 16;
  }
  if (offset !== end - 1 || bytes[offset] !== 0 || !names.size) malformedExr("channel attribute terminator");
  return sizes;
}
