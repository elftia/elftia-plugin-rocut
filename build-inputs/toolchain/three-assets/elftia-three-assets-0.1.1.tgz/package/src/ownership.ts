import { AssetError, type AssetDescriptor, type LoadOptions } from "./types.js";

interface Disposable { dispose(): void }

/** Late parser results are immediately released after cancellation or parse failure. */
export class ResourceScope {
  private readonly resources = new Set<Disposable>();
  private readonly seen = new WeakSet<Disposable>();
  private readonly callbacks = new Set<() => void>();
  private closed = false;

  own<T extends Disposable>(resource: T): T {
    if (!this.seen.has(resource)) {
      this.seen.add(resource);
      if (this.closed) resource.dispose();
      else this.resources.add(resource);
    }
    return resource;
  }

  onDispose(callback: () => void): void {
    if (this.closed) callback();
    else this.callbacks.add(callback);
  }

  dispose(): void {
    if (this.closed) return;
    this.closed = true;
    const resources = [...this.resources], callbacks = [...this.callbacks], errors: unknown[] = [];
    this.resources.clear();
    this.callbacks.clear();
    for (const resource of resources) { try { resource.dispose(); } catch (error) { errors.push(error); } }
    for (const callback of callbacks) { try { callback(); } catch (error) { errors.push(error); } }
    if (errors.length === 1) throw errors[0];
    if (errors.length) throw new AggregateError(errors, "Three resources cleanup failed", { cause: errors[0] });
  }
}

export function checkActive(signal?: AbortSignal): void {
  if (signal?.aborted) throw new DOMException("Asset load cancelled", "AbortError");
}

/** Preserve error identity for callers which classify DOMException or AssetError. */
function withCleanupDiagnostic(primary: unknown, cleanup: unknown): unknown {
  if ((typeof primary === "object" && primary !== null) || typeof primary === "function") {
    try { Object.defineProperty(primary, "cleanupError", { value: cleanup, configurable: true }); } catch { /* Frozen errors still retain their classification. */ }
    return primary;
  }
  return new AggregateError([primary, cleanup], "Asset load and cleanup failed", { cause: primary });
}

export async function ownedLoad<T>(options: LoadOptions, operation: (scope: ResourceScope) => Promise<T>): Promise<T> {
  checkActive(options.signal);
  const scope = new ResourceScope();
  let abort: (() => void) | undefined;
  const cancelled = new Promise<never>((_, reject) => {
    abort = () => {
      const error = new DOMException("Asset load cancelled", "AbortError");
      try { scope.dispose(); } catch (cleanup) {
        reject(withCleanupDiagnostic(error, cleanup));
        return;
      }
      reject(error);
    };
    options.signal?.addEventListener("abort", abort, { once: true });
  });
  try {
    return await Promise.race([operation(scope).then((value) => { checkActive(options.signal); return value; }), cancelled]);
  } catch (error) {
    try { scope.dispose(); } catch (cleanup) {
      throw withCleanupDiagnostic(error, cleanup);
    }
    throw error;
  } finally {
    if (abort) options.signal?.removeEventListener("abort", abort);
  }
}

export async function readVerified(asset: AssetDescriptor, options: LoadOptions): Promise<ArrayBuffer> {
  for (const key of ["maxBytes", "maxDecodedBytes", "maxDimension", "maxObjects"] as const) {
    const value = options.limits[key];
    if (!Number.isSafeInteger(value) || value <= 0) throw new AssetError("INVALID_ASSET", "Asset limits must be positive safe integers");
  }
  if (!asset.id || !/^[a-f0-9]{64}$/u.test(asset.sha256) || !Number.isSafeInteger(asset.byteLength) || asset.byteLength <= 0) {
    throw new AssetError("INVALID_ASSET", "Invalid asset descriptor");
  }
  if (asset.byteLength > options.limits.maxBytes) throw new AssetError("LIMIT_EXCEEDED", "Encoded asset exceeds byte limit");
  checkActive(options.signal);
  const source = await options.resolver.read(asset.id, options.signal);
  checkActive(options.signal);
  if (!(source instanceof ArrayBuffer) || source.byteLength !== asset.byteLength) throw new AssetError("INTEGRITY", "Asset byte length mismatch");
  // Do not parse a caller-owned buffer which may change after verification.
  const bytes = source.slice(0);
  if (!options.digestSha256 && !globalThis.crypto?.subtle) throw new AssetError("UNSUPPORTED", "SHA-256 requires Web Crypto or a trusted digest adapter");
  const digest = options.digestSha256
    ? await options.digestSha256(bytes.slice(0))
    : await crypto.subtle.digest("SHA-256", bytes);
  if (!(digest instanceof ArrayBuffer) || digest.byteLength !== 32) throw new AssetError("INTEGRITY", "Invalid SHA-256 digest result");
  const hash = new Uint8Array(digest);
  if (Array.from(hash, (value) => value.toString(16).padStart(2, "0")).join("") !== asset.sha256) throw new AssetError("INTEGRITY", "Asset SHA-256 mismatch");
  checkActive(options.signal);
  return bytes;
}

export function boundedDimensions(width: number, height: number, bytesPerPixel: number, options: LoadOptions): void {
  if (!Number.isSafeInteger(width) || !Number.isSafeInteger(height) || width <= 0 || height <= 0) throw new AssetError("INVALID_ASSET", "Invalid image dimensions");
  if (width > options.limits.maxDimension || height > options.limits.maxDimension || width * height * bytesPerPixel > options.limits.maxDecodedBytes) {
    throw new AssetError("LIMIT_EXCEEDED", "Decoded image exceeds limits");
  }
}
