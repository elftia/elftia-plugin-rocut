import { AssetError } from "./types.js";
import { validateExrPayload } from "./exr-codecs.js";
import { malformedExr } from "./exr-compression.js";

export interface ExrTiles { width: number; height: number; mode: number }

export function validateExrTiles(buffer: ArrayBuffer, table: number, width: number, height: number, channels: readonly number[], compression: number, tiles: ExrTiles, maximumBlocks: number): void {
  if ((tiles.mode & ~0x11) !== 0) throw new AssetError("UNSUPPORTED", "EXR ripmaps are not supported by Three.js");
  if (!tiles.width || !tiles.height || tiles.width > 16384 || tiles.height > 16384) malformedExr("tile dimensions");
  const round = tiles.mode & 0x10 ? Math.ceil : Math.floor;
  const levels = tiles.mode & 1 ? round(Math.log2(Math.max(width, height))) + 1 : 1;
  const shapes = Array.from({ length: levels }, (_, level) => ({ width: Math.max(1, round(width / 2 ** level)), height: Math.max(1, round(height / 2 ** level)) }));
  const count = shapes.reduce((sum, shape) => sum + Math.ceil(shape.width / tiles.width) * Math.ceil(shape.height / tiles.height), 0);
  if (count > maximumBlocks) throw new AssetError("LIMIT_EXCEEDED", "EXR tile count exceeds limits");
  const data = new DataView(buffer);
  const bytes = new Uint8Array(buffer);
  let position = table + count * 8;
  if (position > bytes.length) malformedExr("tile offset table");
  const offsets = new Set<number>();
  for (let index = 0; index < count; index++) {
    const offset = Number(data.getBigUint64(table + index * 8, true));
    if (!Number.isSafeInteger(offset) || offset < position || offset + 20 > bytes.length || offsets.has(offset)) malformedExr("tile offset");
    offsets.add(offset);
  }
  const identities = new Set<string>();
  let previousLevel = 0;
  for (let index = 0; index < count; index++) {
    if (!offsets.has(position) || position + 20 > bytes.length) malformedExr("tile payload offset");
    const x = data.getInt32(position, true), y = data.getInt32(position + 4, true);
    const level = data.getInt32(position + 8, true), levelY = data.getInt32(position + 12, true);
    const length = data.getUint32(position + 16, true);
    const shape = shapes[level];
    // The target Three loader reads physical chunks, not the offset table; level zero must come first.
    if (!shape || level !== levelY || level < previousLevel || x < 0 || y < 0 || x * tiles.width >= shape.width || y * tiles.height >= shape.height) malformedExr("tile coordinates or level order");
    previousLevel = level;
    const identity = `${level}:${x}:${y}`;
    if (identities.has(identity) || position + 20 + length > bytes.length) malformedExr("duplicate or truncated tile");
    identities.add(identity);
    validateExrPayload(bytes.subarray(position + 20, position + 20 + length), Math.min(tiles.width, shape.width - x * tiles.width), Math.min(tiles.height, shape.height - y * tiles.height), channels, compression);
    position += 20 + length;
  }
  if (position !== bytes.length) malformedExr("tile trailing bytes");
}
