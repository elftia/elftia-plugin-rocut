import { Line, Material, Mesh, Points, SkinnedMesh, Texture } from "three";
import type { GLTF } from "three/addons/loaders/GLTFLoader.js";
import { clone } from "three/addons/utils/SkeletonUtils.js";
import { ResourceScope } from "./ownership.js";
import { AssetError, type LoadedModel } from "./types.js";

export function modelHandle(gltf: GLTF, source: ResourceScope): LoadedModel {
  let loaded: GLTF | null = gltf;
  let closed = false;
  let instances = 0;
  const release = (): void => { if (closed && instances === 0 && loaded) { loaded = null; source.dispose(); } };
  return {
    createInstance() {
      if (closed || !loaded) throw new AssetError("DISPOSED", "Model has been disposed");
      const resources = new ResourceScope();
      const materials = new Map<Material, Material>();
      const textures = new Map<Texture, Texture>();
      const copyMaterial = (original: Material): Material => {
        let copy = materials.get(original);
        if (copy) return copy;
        copy = resources.own(original.clone());
        materials.set(original, copy);
        for (const [key, value] of Object.entries(copy)) if (value instanceof Texture) {
          let texture = textures.get(value);
          if (!texture) { texture = resources.own(value.clone()); textures.set(value, texture); }
          Object.assign(copy, { [key]: texture });
        }
        return copy;
      };
      try {
        // SkeletonUtils remaps bone references; Object3D.clone(true) does not.
        const value = clone(loaded.scene) as GLTF["scene"];
        value.traverse((object) => {
          if (object instanceof Mesh || object instanceof Line || object instanceof Points) {
            object.material = Array.isArray(object.material) ? object.material.map(copyMaterial) : copyMaterial(object.material);
            if (object instanceof SkinnedMesh) resources.own(object.skeleton);
          }
        });
        const animations = loaded.animations.map((animation) => animation.clone());
        instances++;
        let disposed = false;
        return { value, animations, dispose() {
          if (disposed) return;
          disposed = true;
          const errors: unknown[] = [];
          try { value.removeFromParent(); } catch (error) { errors.push(error); }
          try { resources.dispose(); } catch (error) { errors.push(error); }
          finally {
            instances--;
            try { release(); } catch (error) { errors.push(error); }
          }
          if (errors.length === 1) throw errors[0];
          if (errors.length) throw new AggregateError(errors, "Model instance cleanup failed", { cause: errors[0] });
        } };
      } catch (error) {
        try { resources.dispose(); } catch (cleanup) {
          throw new AggregateError([error, cleanup], "Model instance creation and cleanup failed", { cause: error });
        }
        throw error;
      }
    },
    dispose() { closed = true; release(); },
  };
}
