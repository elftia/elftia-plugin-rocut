import { inflateBounded, malformedExr, validateHuffman, validateRle } from "./exr-compression.js";
import { AssetError } from "./types.js";
import { validateDwa } from "./exr-dwa.js";

export const exrBlockHeights = [1, 1, 1, 16, 32, 16, 32, 32, 32, 256] as const;

export function validateExrPayload(bytes: Uint8Array, width: number, height: number, channelSizes: readonly number[], compression: number): void {
  const expected = width * height * channelSizes.reduce((sum, size) => sum + size, 0);
  if (bytes.length === expected) return; // EXR stores incompressible blocks raw.
  if (!bytes.length || bytes.length > expected || compression === 0) malformedExr("block length");
  if (compression === 1) validateRle(bytes, expected);
  else if (compression === 2 || compression === 3) inflateBounded(bytes, expected, expected);
  else if (compression === 4) validatePiz(bytes);
  else if (compression === 5) {
    const packed = width * height * channelSizes.reduce((sum, size) => sum + (size === 4 ? 3 : size), 0);
    inflateBounded(bytes, packed, packed);
  } else if (compression === 6 || compression === 7) validateB44(bytes, width, height, channelSizes, compression === 7);
  else if (compression === 8 || compression === 9) validateDwa(bytes, width, height, channelSizes);
  else throw new AssetError("UNSUPPORTED", "Unknown EXR compression");
}

function validatePiz(bytes: Uint8Array): void {
  if (bytes.length < 8) malformedExr("PIZ header");
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const first = view.getUint16(0, true), last = view.getUint16(2, true);
  if (last >= 8192) malformedExr("PIZ bitmap");
  const offset = 4 + (first <= last ? last - first + 1 : 0);
  if (offset + 4 > bytes.length || view.getUint32(offset, true) !== bytes.length - offset - 4) malformedExr("PIZ compressed size");
  validateHuffman(bytes.subarray(offset + 4));
}

function validateB44(bytes: Uint8Array, width: number, height: number, channelSizes: readonly number[], flat: boolean): void {
  let offset = 0;
  for (const size of channelSizes) {
    if (size !== 2) { offset += width * height * size; continue; }
    const count = Math.ceil(width / 4) * Math.ceil(height / 4);
    for (let block = 0; block < count; block++) {
      if (offset + 3 > bytes.length) malformedExr("B44 header");
      offset += flat && bytes[offset + 2]! >= 52 ? 3 : 14;
      if (offset > bytes.length) malformedExr("B44 block");
    }
  }
  if (offset !== bytes.length) malformedExr("B44 payload length");
}
