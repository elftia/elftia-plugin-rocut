import type { AnimationClip, Group } from "three";

export interface AssetDescriptor {
  readonly id: string;
  readonly mediaType: string;
  readonly byteLength: number;
  readonly sha256: string;
}

/** Implementations enforce transport limits as well as returning authorized bytes. */
export interface AssetBytesResolver {
  read(id: string, signal?: AbortSignal): Promise<ArrayBuffer>;
}

export interface AssetLimits {
  readonly maxBytes: number;
  readonly maxDecodedBytes: number;
  readonly maxDimension: number;
  readonly maxObjects: number;
}

export interface DecodedImage {
  readonly image: ImageBitmap;
  close(): void;
}

/** A decoder must honor orientation and return an independently owned image. */
export type ImageDecoder = (bytes: ArrayBuffer, mimeType: string, flipY: boolean) => Promise<DecodedImage>;

export interface LoadOptions {
  readonly resolver: AssetBytesResolver;
  readonly limits: AssetLimits;
  readonly signal?: AbortSignal;
  readonly decodeImage?: ImageDecoder;
  /** Trusted runtime adapter for opaque origins without Web Crypto. Receives a copy. */
  readonly digestSha256?: (bytes: ArrayBuffer) => Promise<ArrayBuffer>;
}

export interface LoadedAsset<T> {
  readonly value: T;
  dispose(): void;
}

export interface ModelInstance extends LoadedAsset<Group> {
  /** Instance-owned clips. Geometry is shared, immutable, and retained by this lease. */
  readonly animations: readonly AnimationClip[];
}

export interface LoadedModel {
  createInstance(): ModelInstance;
  /** Stops new instances. Existing leases remain valid until individually disposed. */
  dispose(): void;
}

export type AssetErrorCode = "INVALID_ASSET" | "LIMIT_EXCEEDED" | "INTEGRITY" | "UNSUPPORTED" | "DISPOSED";

export class AssetError extends Error {
  constructor(readonly code: AssetErrorCode, message: string) {
    super(message);
    this.name = "AssetError";
  }
}
