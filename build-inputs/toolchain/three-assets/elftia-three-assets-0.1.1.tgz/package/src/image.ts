import { NoColorSpace, SRGBColorSpace, Texture } from "three";
import { boundedDimensions, checkActive, ownedLoad, readVerified, type ResourceScope } from "./ownership.js";
import { AssetError, type AssetDescriptor, type ImageDecoder, type LoadedAsset, type LoadOptions } from "./types.js";

export function imageDimensions(buffer: ArrayBuffer, mediaType: string): readonly [number, number] {
  const data = new DataView(buffer);
  const bytes = new Uint8Array(buffer);
  const ascii = (start: number, count: number): string => String.fromCharCode(...bytes.subarray(start, start + count));
  const invalid = (): never => { throw new AssetError("INVALID_ASSET", `Malformed ${mediaType} image`); };
  if (mediaType === "image/png") {
    if (bytes.length < 33 || data.getUint32(0) !== 0x89504e47 || data.getUint32(4) !== 0x0d0a1a0a || data.getUint32(8) !== 13 || ascii(12, 4) !== "IHDR") return invalid();
    return [data.getUint32(16), data.getUint32(20)];
  }
  if (mediaType === "image/jpeg") {
    if (bytes.length < 4 || data.getUint16(0) !== 0xffd8) return invalid();
    let offset = 2;
    while (offset + 4 <= bytes.length) {
      if (bytes[offset++] !== 0xff) return invalid();
      while (bytes[offset] === 0xff) offset++;
      const marker = bytes[offset++];
      if (marker === undefined || marker === 0xda || marker === 0xd9 || offset + 2 > bytes.length) return invalid();
      const length = data.getUint16(offset);
      if (length < 2 || offset + length > bytes.length) return invalid();
      if ([0xc0, 0xc1, 0xc2].includes(marker)) {
        if (length < 8) return invalid();
        return [data.getUint16(offset + 5), data.getUint16(offset + 3)];
      }
      offset += length;
    }
    return invalid();
  }
  if (mediaType === "image/webp") {
    if (bytes.length < 30 || ascii(0, 4) !== "RIFF" || ascii(8, 4) !== "WEBP" || data.getUint32(4, true) + 8 !== bytes.length) return invalid();
    const kind = ascii(12, 4);
    if (kind === "VP8X") {
      if ((bytes[20]! & 2) !== 0) throw new AssetError("UNSUPPORTED", "Animated WebP is not a deterministic texture");
      return [1 + (data.getUint32(24, true) & 0xffffff), 1 + (data.getUint32(26, true) >>> 8)];
    }
    if (kind === "VP8 " && data.getUint8(23) === 0x9d && data.getUint16(24) === 0x012a) return [data.getUint16(26, true) & 0x3fff, data.getUint16(28, true) & 0x3fff];
    if (kind === "VP8L" && bytes[20] === 0x2f) {
      const packed = data.getUint32(21, true);
      return [1 + (packed & 0x3fff), 1 + ((packed >>> 14) & 0x3fff)];
    }
    return invalid();
  }
  throw new AssetError("UNSUPPORTED", `Unsupported image type: ${mediaType}`);
}

const browserImageDecoder: ImageDecoder = async (bytes, type, flipY) => {
  if (typeof createImageBitmap !== "function") throw new AssetError("UNSUPPORTED", "An ImageBitmap decoder is required in this runtime");
  const image = await createImageBitmap(new Blob([bytes], { type }), {
    imageOrientation: flipY ? "flipY" : "none", premultiplyAlpha: "none", colorSpaceConversion: "none",
  });
  return { image, close: () => image.close() };
};

export async function decodeTexture(bytes: ArrayBuffer, mediaType: string, flipY: boolean, options: LoadOptions, scope: ResourceScope): Promise<Texture> {
  const [width, height] = imageDimensions(bytes, mediaType);
  boundedDimensions(width, height, 4, options);
  checkActive(options.signal);
  const decoded = await (options.decodeImage ?? browserImageDecoder)(bytes, mediaType, flipY);
  scope.onDispose(() => decoded.close());
  checkActive(options.signal);
  if (decoded.image.width !== width || decoded.image.height !== height) throw new AssetError("INVALID_ASSET", "Image dimensions changed during decode");
  const texture = scope.own(new Texture(decoded.image));
  texture.flipY = false; // ImageBitmap orientation is fixed at decode, not at upload.
  texture.premultiplyAlpha = false;
  texture.needsUpdate = true;
  return texture;
}

export async function loadTexture(asset: AssetDescriptor, options: LoadOptions & { role: "color" | "data"; flipY?: boolean }): Promise<LoadedAsset<Texture>> {
  return ownedLoad(options, async (scope) => {
    const bytes = await readVerified(asset, options);
    const value = await decodeTexture(bytes, asset.mediaType, options.flipY ?? true, options, scope);
    value.colorSpace = options.role === "color" ? SRGBColorSpace : NoColorSpace;
    return { value, dispose: () => scope.dispose() };
  });
}
