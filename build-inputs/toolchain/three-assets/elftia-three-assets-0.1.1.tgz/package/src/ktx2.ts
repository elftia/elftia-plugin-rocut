import { DataTexture, LinearFilter, LinearMipmapLinearFilter, NoColorSpace, RGBAFormat, SRGBColorSpace, UnsignedByteType } from "three";
import createBasis from "./ktx2-basis.js";
import { basisWasmBase64 } from "./ktx2-wasm.js";
import { boundedDimensions, checkActive, type ResourceScope } from "./ownership.js";
import { AssetError, type LoadOptions } from "./types.js";

interface BasisFile {
  isValid(): boolean; isUASTC(): boolean; isETC1S(): boolean; isHDR(): boolean;
  getWidth(): number; getHeight(): number; getLevels(): number; getLayers(): number; getFaces(): number;
  startTranscoding(): boolean;
  getImageTranscodedSizeInBytes(level: number, layer: number, face: number, format: number): number;
  transcodeImage(data: Uint8Array, level: number, layer: number, face: number, format: number, flags: number, channel0: number, channel1: number): boolean;
  close(): void; delete(): void;
}
interface BasisModule { initializeBasis(): void; KTX2File: new (bytes: Uint8Array) => BasisFile }
let basis: Promise<BasisModule> | undefined;

function decoder(): Promise<BasisModule> {
  basis ??= (async () => {
    const binary = atob(basisWasmBase64);
    const wasmBinary = Uint8Array.from(binary, (character) => character.charCodeAt(0));
    const result = await createBasis({ wasmBinary, print: () => {}, printErr: () => {} }) as BasisModule;
    result.initializeBasis();
    return result;
  })();
  return basis;
}

const invalid = (message: string): never => { throw new AssetError("INVALID_ASSET", message); };
const unsupported = (message: string): never => { throw new AssetError("UNSUPPORTED", message); };

/** Preflight precedes any WASM allocation. Only standalone 2D LDR Basis images are supported. */
export function ktx2Dimensions(bytes: ArrayBuffer, options: LoadOptions): { width: number; height: number; levels: number; decodedBytes: number; srgb: boolean; premultiplyAlpha: boolean } {
  if (bytes.byteLength > Math.min(options.limits.maxBytes, 16 * 1024 * 1024)) throw new AssetError("LIMIT_EXCEEDED", "Encoded KTX2 exceeds byte limit or fixed decoder capacity");
  const view = new DataView(bytes);
  const signature = [0xab, 0x4b, 0x54, 0x58, 0x20, 0x32, 0x30, 0xbb, 0x0d, 0x0a, 0x1a, 0x0a];
  if (bytes.byteLength < 104 || signature.some((value, index) => view.getUint8(index) !== value)) return invalid("Malformed KTX2 header");
  const u32 = (offset: number): number => view.getUint32(offset, true);
  const u64 = (offset: number): number => {
    const value = Number(view.getBigUint64(offset, true));
    if (!Number.isSafeInteger(value)) return invalid("Unsafe KTX2 byte range");
    return value;
  };
  const width = u32(20), height = u32(24), levels = u32(40), scheme = u32(44);
  boundedDimensions(width, height, 4, options);
  if (u32(28) !== 0 || u32(32) !== 0 || u32(36) !== 1) return unsupported("KTX2 requires a non-array 2D texture with one face");
  if (u32(12) !== 0 || u32(16) !== 1 || (scheme !== 0 && scheme !== 1)) return unsupported("KTX2 supports only LDR ETC1S/BasisLZ or uncompressed UASTC");
  if (levels < 1 || levels > 1 + Math.floor(Math.log2(Math.max(width, height))) || 80 + levels * 24 > bytes.byteLength) return invalid("Invalid KTX2 mip count");
  const ranges: { offset: number; length: number }[] = [{ offset: 0, length: 80 + levels * 24 }];
  const range = (offset: number, length: number): void => {
    if (!Number.isSafeInteger(offset + length) || offset < 0 || length < 0 || offset + length > bytes.byteLength) return invalid("KTX2 byte range exceeds input");
    if (!length) return;
    if (ranges.some((other) => offset < other.offset + other.length && other.offset < offset + length)) return invalid("Overlapping KTX2 byte ranges");
    ranges.push({ offset, length });
  };
  const dfd = u32(48), dfdLength = u32(52);
  const sgd = u64(64), sgdLength = u64(72);
  range(dfd, dfdLength); range(u32(56), u32(60)); range(sgd, sgdLength);
  const kvdEnd = u32(56) + u32(60);
  for (let offset = u32(56); offset < kvdEnd;) {
    if (offset + 4 > kvdEnd) return invalid("Truncated KTX2 key/value length");
    const length = u32(offset);
    offset += 4;
    if (!length || offset + length > kvdEnd) return invalid("Invalid KTX2 key/value range");
    const entry = new Uint8Array(bytes, offset, length), separator = entry.indexOf(0);
    if (separator < 1) return invalid("Invalid KTX2 metadata key");
    const key = new TextDecoder().decode(entry.subarray(0, separator));
    const value = new TextDecoder().decode(entry.subarray(separator + 1)).replace(/\0$/u, "");
    if (key === "KTXanimData") return unsupported("KTX2 video textures are unsupported");
    if ((key === "KTXorientation" && value !== "rd") || (key === "KTXswizzle" && value !== "rgba")) return unsupported("Unsupported KTX2 orientation or channel swizzle");
    offset += Math.ceil(length / 4) * 4;
    if (offset > kvdEnd) return invalid("Invalid KTX2 metadata padding");
  }
  if (dfdLength < 28 || u32(dfd) !== dfdLength || view.getUint16(dfd + 10, true) + 4 > dfdLength) return invalid("Malformed KTX2 data format descriptor");
  const model = view.getUint8(dfd + 12), transfer = view.getUint8(dfd + 14), flags = view.getUint8(dfd + 15);
  if ((model !== 163 || scheme !== 1) && (model !== 166 || scheme !== 0)) return unsupported("Unsupported KTX2 Basis encoding");
  if (transfer !== 1 && transfer !== 2) return unsupported("Unsupported KTX2 transfer function");
  if (flags !== 0) return unsupported("KTX2 premultiplied alpha and nonzero DFD flags are unsupported");
  if (model === 163) {
    const descriptorsEnd = 20 + levels * 20;
    if (sgdLength < descriptorsEnd) return invalid("Truncated KTX2 Basis global data");
    const codebookLength = u32(sgd + 4) + u32(sgd + 8) + u32(sgd + 12) + u32(sgd + 16);
    if (descriptorsEnd + codebookLength !== sgdLength) return invalid("Invalid KTX2 Basis codebook ranges");
    for (let level = 0; level < levels; level++) {
      const descriptor = sgd + 20 + level * 20, mipLength = u64(88 + level * 24);
      if (u32(descriptor) !== 0) return unsupported("KTX2 video and image flags are unsupported");
      for (const slice of [descriptor + 4, descriptor + 12]) {
        if (u32(slice) + u32(slice + 4) > mipLength) return invalid("KTX2 Basis slice exceeds mip payload");
      }
    }
  } else if (sgdLength !== 0) return invalid("Unexpected KTX2 UASTC global data");
  let decodedBytes = 0;
  for (let level = 0; level < levels; level++) {
    const index = 80 + 24 * level, length = u64(index + 8), unpacked = u64(index + 16);
    range(u64(index), length);
    if (length === 0 || (scheme === 0 && unpacked !== length) || (scheme === 1 && unpacked !== 0)) return invalid("Invalid KTX2 mip byte length");
    const mipWidth = Math.max(1, Math.floor(width / 2 ** level)), mipHeight = Math.max(1, Math.floor(height / 2 ** level));
    decodedBytes += mipWidth * mipHeight * 4;
    if (!Number.isSafeInteger(decodedBytes) || decodedBytes > Math.min(options.limits.maxDecodedBytes, 32 * 1024 * 1024)) throw new AssetError("LIMIT_EXCEEDED", "KTX2 mip chain exceeds decoded byte limit or fixed decoder capacity");
    if (model === 166 && length !== Math.ceil(mipWidth / 4) * Math.ceil(mipHeight / 4) * 16) return invalid("Invalid KTX2 UASTC block length");
  }
  return { width, height, levels, decodedBytes, srgb: transfer === 2, premultiplyAlpha: false };
}

/** Decodes embedded KHR_texture_basisu images without renderer capabilities or external URLs. */
export async function decodeKtx2Texture(bytes: ArrayBuffer, options: LoadOptions, scope: ResourceScope): Promise<DataTexture> {
  checkActive(options.signal);
  const header = ktx2Dimensions(bytes, options);
  const module = await decoder();
  checkActive(options.signal);
  const file = new module.KTX2File(new Uint8Array(bytes));
  const mipmaps: { data: Uint8Array<ArrayBuffer>; width: number; height: number }[] = [];
  try {
    if (!file.isValid()) return invalid("Invalid KTX2 Basis payload");
    if (file.isHDR() || (!file.isUASTC() && !file.isETC1S())) return unsupported("Unsupported KTX2 Basis payload");
    if (file.getWidth() !== header.width || file.getHeight() !== header.height || file.getLevels() !== header.levels || file.getLayers() !== 0 || file.getFaces() !== 1) return invalid("KTX2 decoder metadata differs from header");
    if (!file.startTranscoding()) return invalid("KTX2 Basis transcoding failed to start");
    for (let level = 0; level < header.levels; level++) {
      checkActive(options.signal);
      const width = Math.max(1, Math.floor(header.width / 2 ** level)), height = Math.max(1, Math.floor(header.height / 2 ** level));
      const length = file.getImageTranscodedSizeInBytes(level, 0, 0, 13);
      if (length !== width * height * 4) return invalid("KTX2 transcoded byte length differs from preflight");
      const data = new Uint8Array(length);
      if (!file.transcodeImage(data, level, 0, 0, 13, 0, -1, -1)) return invalid("KTX2 Basis mip decode failed");
      mipmaps.push({ data, width, height });
    }
  } catch (error) {
    if (error instanceof AssetError || (error instanceof DOMException && error.name === "AbortError")) throw error;
    throw new AssetError("INVALID_ASSET", "KTX2 Basis decoder rejected payload");
  } finally {
    try { file.close(); } finally { file.delete(); }
  }
  checkActive(options.signal);
  const texture = scope.own(new DataTexture(mipmaps[0]!.data, header.width, header.height, RGBAFormat, UnsignedByteType));
  if (header.levels > 1) texture.mipmaps = mipmaps;
  texture.minFilter = header.levels > 1 ? LinearMipmapLinearFilter : LinearFilter;
  texture.magFilter = LinearFilter;
  texture.generateMipmaps = false;
  texture.flipY = false;
  texture.premultiplyAlpha = header.premultiplyAlpha;
  texture.colorSpace = header.srgb ? SRGBColorSpace : NoColorSpace;
  texture.needsUpdate = true;
  return texture;
}
