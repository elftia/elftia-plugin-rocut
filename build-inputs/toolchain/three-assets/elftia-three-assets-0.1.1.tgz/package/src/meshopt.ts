import { integer, list, record, type JsonRecord } from "./glb-validation.js";
import { checkActive } from "./ownership.js";
import { AssetError, type LoadOptions } from "./types.js";

const names = ["EXT_meshopt_compression", "KHR_meshopt_compression"] as const;
export interface MeshoptView {
  readonly buffer: number;
  readonly offset: number;
  readonly length: number;
  readonly count: number;
  readonly stride: number;
  readonly mode: "ATTRIBUTES" | "TRIANGLES" | "INDICES";
  readonly filter: "NONE" | "OCTAHEDRAL" | "QUATERNION" | "EXPONENTIAL" | "COLOR";
}
export function meshoptDefinition(view: JsonRecord): { name: typeof names[number]; value: JsonRecord } | undefined {
  if (view.extensions === undefined) return undefined;
  const extensions = record(view.extensions), present = names.filter(name => extensions[name] !== undefined);
  if (present.length > 1) throw new AssetError("INVALID_ASSET", "Ambiguous Meshopt extensions");
  const name = present[0];
  return name ? { name, value: record(extensions[name]) } : undefined;
}

/** Metadata only. All lengths, references and output budgets precede decoder import/allocation. */
export function planMeshoptViews(json: JsonRecord, buffers: readonly (ArrayBuffer | undefined)[], options: LoadOptions, account: (bytes: number) => void): (MeshoptView | undefined)[] {
  const definitions = list(json.buffers).map(record), views = list(json.bufferViews).map(record);
  let decodedBudget = 0;
  const plans = views.map(view => {
    const extension = meshoptDefinition(view);
    if (!extension) return undefined;
    if (!list(json.extensionsUsed).includes(extension.name)) throw new AssetError("INVALID_ASSET", "Meshopt extension is not declared in extensionsUsed");
    const def = extension.value;
    if (Object.keys(def).some(key => !["buffer", "byteOffset", "byteLength", "byteStride", "count", "mode", "filter"].includes(key))) throw new AssetError("INVALID_ASSET", "Unsupported Meshopt extension field");
    const buffer = integer(def.buffer, buffers.length - 1), source = buffers[buffer];
    if (!source) throw new AssetError("INVALID_ASSET", "Meshopt compressed source must be embedded, not fallback");
    const offset = integer(def.byteOffset ?? 0, source.byteLength), length = integer(def.byteLength, source.byteLength, 1);
    if (offset + length > source.byteLength) throw new AssetError("INVALID_ASSET", "Meshopt source range exceeds buffer");
    const count = integer(def.count, options.limits.maxDecodedBytes, 1), stride = integer(def.byteStride, 256, 1);
    const mode = def.mode, filter = def.filter ?? "NONE";
    if (mode !== "ATTRIBUTES" && mode !== "TRIANGLES" && mode !== "INDICES") throw new AssetError("INVALID_ASSET", "Invalid Meshopt mode");
    if (!["NONE", "OCTAHEDRAL", "QUATERNION", "EXPONENTIAL", ...(extension.name === "KHR_meshopt_compression" ? ["COLOR"] : [])].includes(String(filter))) throw new AssetError("INVALID_ASSET", "Invalid Meshopt filter");
    if (mode === "ATTRIBUTES" ? stride % 4 !== 0 : ![2, 4].includes(stride) || filter !== "NONE") throw new AssetError("INVALID_ASSET", "Invalid Meshopt mode stride/filter");
    if (mode === "TRIANGLES" && count % 3 !== 0) throw new AssetError("INVALID_ASSET", "Meshopt triangle count must be divisible by three");
    const header = new Uint8Array(source, offset, 1)[0];
    const headers = mode === "ATTRIBUTES" ? [0xa0, ...(extension.name === "KHR_meshopt_compression" ? [0xa1] : [])] : mode === "TRIANGLES" ? [0xe0, ...(extension.name === "KHR_meshopt_compression" ? [0xe1] : [])] : [0xd1];
    if (!headers.includes(header!)) throw new AssetError("INVALID_ASSET", "Meshopt bitstream header/version mismatch");
    if ((filter === "OCTAHEDRAL" || filter === "COLOR") && ![4, 8].includes(stride) || filter === "QUATERNION" && stride !== 8 || filter === "EXPONENTIAL" && stride % 4 !== 0) throw new AssetError("INVALID_ASSET", "Invalid Meshopt filter stride");
    if (view.byteStride !== undefined && view.byteStride !== stride || view.byteLength !== count * stride) throw new AssetError("INVALID_ASSET", "Meshopt decoded layout mismatch");
    decodedBudget += count * stride + Math.ceil(count / 4) * 4 * stride + length;
    if (!Number.isSafeInteger(decodedBudget) || decodedBudget > Math.min(options.limits.maxDecodedBytes, 64 * 1024 * 1024)) throw new AssetError("LIMIT_EXCEEDED", "Meshopt output/scratch budget exceeded");
    // Fixed decoder pads count to four and maintains a WASM scratch copy of source/output.
    // Account conservatively for output retention, padded scratch and encoded scratch.
    account(count * stride + Math.ceil(count / 4) * 4 * stride + length);
    return { buffer, offset, length, count, stride, mode, filter } as MeshoptView;
  });
  definitions.forEach((buffer, index) => {
    const tagged = meshoptDefinition(buffer);
    if (tagged && (tagged.value.fallback !== true || Object.keys(tagged.value).some(key => key !== "fallback"))) throw new AssetError("INVALID_ASSET", "Invalid Meshopt fallback buffer marker");
    const refs = views.map((view, viewIndex) => ({ view, viewIndex })).filter(({view}) => view.buffer === index);
    if (!buffers[index] || tagged) {
      if (!refs.length || refs.some(({view,viewIndex}) => !plans[viewIndex] || tagged && !record(view.extensions)[tagged.name])) throw new AssetError("INVALID_ASSET", "Fallback buffer has non-Meshopt references");
      if (plans.some(plan => plan?.buffer === index)) throw new AssetError("INVALID_ASSET", "Fallback buffer cannot contain compressed data");
      if (!buffers[index] && refs.some(({view}) => !list(json.extensionsRequired).includes(meshoptDefinition(view)!.name))) throw new AssetError("INVALID_ASSET", "Missing fallback requires Meshopt extension");
    }
  });
  return plans;
}

/** Fixed local addon only. Never creates workers, fetches modules, or accepts author decoders. */
export async function decodeMeshoptViews(plans: readonly (MeshoptView | undefined)[], buffers: readonly (ArrayBuffer | undefined)[], views: ArrayBuffer[], options: LoadOptions): Promise<void> {
  if (!plans.some(Boolean)) return;
  checkActive(options.signal);
  const { MeshoptDecoder } = await import("three/addons/libs/meshopt_decoder.module.js");
  if (!MeshoptDecoder.supported) throw new AssetError("UNSUPPORTED", "Fixed Meshopt decoder unavailable");
  await MeshoptDecoder.ready;
  checkActive(options.signal);
  try {
    for (let index = 0; index < plans.length; index++) {
      const plan = plans[index];
      if (!plan) continue;
      checkActive(options.signal);
      const output = new Uint8Array(plan.count * plan.stride);
      MeshoptDecoder.decodeGltfBuffer(output, plan.count, plan.stride, new Uint8Array(buffers[plan.buffer]!, plan.offset, plan.length), plan.mode, plan.filter);
      checkActive(options.signal);
      views[index] = output.buffer;
    }
  } catch (error) {
    views.length = 0;
    if (options.signal?.aborted) checkActive(options.signal);
    throw new AssetError("INVALID_ASSET", `Meshopt decode failed: ${error instanceof Error ? error.message : "invalid stream"}`);
  }
}
