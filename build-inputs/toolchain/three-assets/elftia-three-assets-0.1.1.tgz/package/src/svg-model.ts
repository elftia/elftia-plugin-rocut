import { DoubleSide, ExtrudeGeometry, Group, Mesh, MeshBasicMaterial, ShapeGeometry } from "three";
import { SVGLoader } from "three/addons/loaders/SVGLoader.js";
import type { GLTF } from "three/addons/loaders/GLTFLoader.js";
import { modelHandle } from "./model-instance.js";
import { checkActive, ownedLoad, readVerified } from "./ownership.js";
import { AssetError, type AssetDescriptor, type LoadedModel, type LoadOptions } from "./types.js";

export interface SvgModelOptions extends LoadOptions {
  /** Required explicit modeling choice. Depth is in SVG viewBox units. */
  readonly modeling: { readonly kind: "flat" } | { readonly kind: "extrude"; readonly depth: number };
  readonly curveSegments?: number;
  readonly maxSegments?: number;
  readonly maxVertices?: number;
}

const tags: Record<string, readonly string[]> = {
  svg: ["xmlns", "viewBox"],
  g: [], path: ["d"], rect: ["x", "y", "width", "height", "rx", "ry"],
  circle: ["cx", "cy", "r"], ellipse: ["cx", "cy", "rx", "ry"], polygon: ["points"],
};
const shared = ["fill", "fill-rule", "transform"];
const fail = (message: string): never => { throw new AssetError("UNSUPPORTED", message); };
const limit = (message: string): never => { throw new AssetError("LIMIT_EXCEEDED", message); };

function validatePath(value: string): void {
  const tokens = value.match(/[MmLlHhVvCcSsQqTtAaZz]|[-+]?(?:\d*\.\d+|\d+\.?\d*)/gu) ?? [];
  const sizes: Record<string, number> = { M: 2, L: 2, H: 1, V: 1, C: 6, S: 4, Q: 4, T: 2, A: 7, Z: 0 };
  if (!/^[Mm]$/u.test(tokens[0] ?? "")) throw new AssetError("INVALID_ASSET", "SVG path must begin with moveto");
  for (let index = 0; index < tokens.length;) {
    const command = tokens[index++]!.toUpperCase();
    const size = sizes[command];
    if (size === undefined) throw new AssetError("INVALID_ASSET", "Malformed SVG path command");
    const start = index;
    while (index < tokens.length && !/^[a-z]$/iu.test(tokens[index]!)) index++;
    const length = index - start;
    if (size === 0 ? length !== 0 : length === 0 || length % size !== 0) throw new AssetError("INVALID_ASSET", "Malformed SVG path parameters");
    if (command === "A") for (let item = start; item < index; item += 7) {
      if (Number(tokens[item]) < 0 || Number(tokens[item + 1]) < 0 || !["0", "1"].includes(tokens[item + 3]!) || !["0", "1"].includes(tokens[item + 4]!)) throw new AssetError("INVALID_ASSET", "Malformed SVG arc");
    }
  }
}

function positive(value: number, name: string, maximum: number): number {
  if (!Number.isSafeInteger(value) || value < 1 || value > maximum) throw new AssetError("INVALID_ASSET", `Invalid SVG ${name}`);
  return value;
}

function validate(text: string, options: SvgModelOptions, segments: number): { box: readonly number[]; complexity: number } {
  // Reject declarations before invoking the host XML parser: no DTD/entity expansion.
  if (/<!|<\?/u.test(text)) fail("SVG declarations, entities and comments are unsupported");
  if (typeof DOMParser === "undefined") fail("SVG requires a trusted host DOMParser");
  const document = new DOMParser().parseFromString(text, "image/svg+xml");
  const root = document.documentElement;
  if (document.getElementsByTagName("parsererror").length || root.localName !== "svg") throw new AssetError("INVALID_ASSET", "Malformed SVG document");
  const nodes = [root, ...Array.from(root.getElementsByTagName("*"))];
  if (nodes.length > Math.min(options.limits.maxObjects, 1024)) limit("SVG element budget exceeded");
  let complexity = 0;
  for (const node of nodes) {
    let depth = 0;
    for (let parent = node.parentElement; parent; parent = parent.parentElement) if (++depth > 32) limit("SVG nesting budget exceeded");
    if (node.namespaceURI !== "http://www.w3.org/2000/svg" || !Object.hasOwn(tags, node.localName) || (node !== root && node.localName === "svg")) fail("Unsupported SVG element");
    for (const attribute of Array.from(node.attributes)) {
      const name = attribute.name;
      const value = attribute.value;
      if (["d", "points", "transform"].includes(name)) {
        const numbers = value.match(/[-+]?(?:\d*\.\d+|\d+\.?\d*)(?:[eE][-+]?\d+)?/gu) ?? [];
        if (numbers.some((number) => !Number.isFinite(Number(number)) || Math.abs(Number(number)) > options.limits.maxDimension)) limit("SVG coordinate budget exceeded");
      }
      if (![...tags[node.localName]!, ...shared].includes(name) || /url\s*\(|[\u0000-\u0008]/iu.test(value)) fail("Unsupported SVG attribute or reference");
      if (name === "xmlns" && value !== "http://www.w3.org/2000/svg") fail("Unsupported SVG namespace");
      if (name === "fill" && !/^(?:none|#[\da-f]{3}|#[\da-f]{6}|black|white|red|green|blue)$/iu.test(value)) fail("Unsupported SVG fill");
      if (name === "fill-rule" && !["nonzero", "evenodd"].includes(value)) fail("Unsupported SVG fill rule");
      if (name === "d") {
        if (/[^MmLlHhVvCcSsQqTtAaZz\d+.,\s-]/u.test(value)) fail("Unsupported SVG path data");
        validatePath(value);
        complexity += (value.match(/[MmLlHhVvCcSsQqTtAaZz]|[-+]?(?:\d*\.\d+|\d+\.?\d*)(?:[eE][-+]?\d+)?/gu) ?? []).length;
      } else if (name === "points") {
        if (/[^\d+.,\s-]/u.test(value)) fail("Unsupported SVG points");
        complexity += (value.match(/[-+]?(?:\d*\.\d+|\d+\.?\d*)/gu) ?? []).length;
      } else if (name === "transform") {
        if (!/^(?:\s*(?:matrix|translate|scale|rotate|skewX|skewY)\s*\([\d+.,\s-]+\)\s*)+$/u.test(value)) fail("Unsupported SVG transform");
      } else if (!["xmlns", "fill", "fill-rule", "viewBox"].includes(name)) {
        if (!/^[-+]?(?:\d*\.\d+|\d+\.?\d*)$/u.test(value) || !Number.isFinite(Number(value)) || Math.abs(Number(value)) > options.limits.maxDimension) fail("Unsupported SVG dimension");
        if (["width", "height", "r", "rx", "ry"].includes(name) && Number(value) < 0) throw new AssetError("INVALID_ASSET", "Negative SVG size");
      }
    }
    if (Array.from(node.childNodes).some((child) => child.nodeType === 3 && child.textContent?.trim())) fail("SVG text is unsupported");
    complexity += 16;
    if (complexity > segments) limit("SVG segment budget exceeded");
  }
  const box = (root.getAttribute("viewBox") ?? "").trim().split(/[\s,]+/u).map(Number);
  if (box.length !== 4 || box.some((value) => !Number.isFinite(value) || Math.abs(value) > options.limits.maxDimension) || box[2]! <= 0 || box[3]! <= 0) throw new AssetError("INVALID_ASSET", "SVG requires a bounded viewBox");
  return { box, complexity };
}

/** Static filled SVG subset only. DOMParser is supplied by the trusted host runtime, never the author. */
export async function loadSvgModel(asset: AssetDescriptor, options: SvgModelOptions): Promise<LoadedModel> {
  return ownedLoad(options, async (scope) => {
    if (asset.mediaType !== "image/svg+xml") fail("SVG model requires image/svg+xml");
    const curves = positive(options.curveSegments ?? 8, "curveSegments", 32);
    const segments = positive(options.maxSegments ?? 1024, "maxSegments", 4096);
    const vertices = positive(options.maxVertices ?? 100_000, "maxVertices", 1_000_000);
    if (!options.modeling || !["flat", "extrude"].includes(options.modeling.kind)) fail("Explicit SVG modeling options required");
    if (options.modeling.kind === "extrude" && (!Number.isFinite(options.modeling.depth) || options.modeling.depth <= 0 || options.modeling.depth > options.limits.maxDimension)) throw new AssetError("INVALID_ASSET", "Invalid SVG extrusion depth");
    const bytes = await readVerified(asset, options);
    if (bytes.byteLength * 2 > options.limits.maxDecodedBytes) limit("SVG document exceeds decoded budget");
    let text: string;
    try { text = new TextDecoder("utf-8", { fatal: true }).decode(bytes); }
    catch { throw new AssetError("INVALID_ASSET", "SVG must be UTF-8"); }
    const { box, complexity } = validate(text, options, segments);
    // Bound triangulation input and output before SVGLoader or geometry allocations.
    const worstVertices = complexity * curves * (options.modeling.kind === "extrude" ? 36 : 6);
    if (worstVertices > vertices || worstVertices * 32 > options.limits.maxDecodedBytes) limit("SVG geometry preflight budget exceeded");
    checkActive(options.signal);
    const paths = new SVGLoader().parse(text).paths;
    const scene = new Group();
    let objects = 1;
    let decoded = 0;
    let count = 0;
    for (const path of paths) {
      const style: unknown = path.userData?.style;
      if (typeof style === "object" && style !== null && "fill" in style && style.fill === "none") continue;
      const shapes = SVGLoader.createShapes(path);
      for (const shape of shapes) {
        checkActive(options.signal);
        if (++objects > options.limits.maxObjects) limit("SVG object budget exceeded");
        const geometry = scope.own(options.modeling.kind === "flat"
          ? new ShapeGeometry(shape, curves)
          : new ExtrudeGeometry(shape, { depth: options.modeling.depth, steps: 1, bevelEnabled: false, curveSegments: curves }));
        count += geometry.getAttribute("position").count;
        decoded += Object.values(geometry.attributes).reduce((sum, attribute) => sum + attribute.array.byteLength, 0) + (geometry.index?.array.byteLength ?? 0);
        if (count > vertices || decoded > options.limits.maxDecodedBytes) limit("SVG geometry budget exceeded");
        // SVG y increases downward. Translate viewBox origin and invert geometry y;
        // recompute normals after reflection so extrusion faces remain consistent.
        geometry.translate(-box[0]!, -box[1]!, 0);
        geometry.scale(1, -1, 1);
        const position = geometry.getAttribute("position");
        for (let index = 0; index < position.count; index++) {
          if (![position.getX(index), position.getY(index), position.getZ(index)].every((value) => Number.isFinite(value) && Math.abs(value) <= options.limits.maxDimension * 2)) limit("SVG transformed coordinate budget exceeded");
        }
        // Reflection reverses winding. Preserve outward faces for future materials.
        if (geometry.index) {
          for (let index = 0; index < geometry.index.count; index += 3) {
            const second = geometry.index.getX(index + 1);
            geometry.index.setX(index + 1, geometry.index.getX(index + 2));
            geometry.index.setX(index + 2, second);
          }
        } else {
          for (const attribute of Object.values(geometry.attributes)) {
            for (let index = 0; index < attribute.count; index += 3) {
              for (let component = 0; component < attribute.itemSize; component++) {
                const array = attribute.array;
                const second = (index + 1) * attribute.itemSize + component;
                const third = (index + 2) * attribute.itemSize + component;
                const temporary = array[second]!;
                array[second] = array[third]!; array[third] = temporary;
              }
            }
          }
        }
        geometry.computeVertexNormals();
        const material = scope.own(new MeshBasicMaterial({ color: path.color, side: DoubleSide }));
        scene.add(new Mesh(geometry, material));
      }
    }
    if (objects === 1) throw new AssetError("INVALID_ASSET", "SVG has no filled geometry");
    checkActive(options.signal);
    return modelHandle({ scene, scenes: [scene], animations: [], cameras: [], asset: { version: "2.0" }, userData: {} } as unknown as GLTF, scope);
  });
}
