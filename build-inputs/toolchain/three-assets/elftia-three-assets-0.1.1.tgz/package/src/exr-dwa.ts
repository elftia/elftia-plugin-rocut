import { inflateBounded, malformedExr, validateHuffman, validateRle } from "./exr-compression.js";

/** Validate DWA metadata and normalize the already-owned copy for Three r185. */
export function validateDwa(bytes: Uint8Array, width: number, height: number, channelSizes: readonly number[]): void {
  if (bytes.length < 90) malformedExr("DWA header");
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const fields = Array.from({ length: 11 }, (_, index) => Number(view.getBigUint64(index * 8, true)));
  if (fields.some((value) => !Number.isSafeInteger(value))) malformedExr("DWA integer");
  const [version, unknownRaw, unknownSize, acSize, dcSize, rleSize, rleEncoded, rleRaw, acCount, dcCount, acCompression] = fields as [number, number, number, number, number, number, number, number, number, number, number];
  const pixels = width * height * channelSizes.reduce((sum, size) => sum + size, 0);
  const blocks = Math.ceil(width / 8) * Math.ceil(height / 8) * channelSizes.length;
  if (version < 2 || unknownRaw > pixels || unknownSize > bytes.length || acCount > blocks * 64 || dcCount > blocks || rleRaw > pixels || rleEncoded > pixels * 2 || acCompression > 1) malformedExr("DWA allocation bounds");
  // Three does not implement the UNKNOWN DWA channel path.
  if (unknownSize !== 0 || unknownRaw !== 0) malformedExr("unsupported DWA unknown-channel section");
  let offset = 88;
  const rulesEnd = offset + view.getUint16(offset, true);
  offset += 2;
  if (rulesEnd < offset || rulesEnd > bytes.length) malformedExr("DWA rule length");
  let rules = 0;
  while (offset < rulesEnd) {
    const start = offset;
    while (offset < rulesEnd && bytes[offset] !== 0 && offset - start <= 255) {
      if (bytes[offset]! > 127) malformedExr("DWA channel name encoding");
      offset++;
    }
    if (++rules > 256 || offset - start > 255 || offset + 3 > rulesEnd) malformedExr("DWA channel rule");
    const rule = bytes[offset + 1]!;
    if (((rule >> 2) & 3) > 2 || (rule >> 4) > 3 || ![1, 2].includes(bytes[offset + 2]!)) malformedExr("DWA channel type");
    offset += 3;
  }
  const section = (size: number): Uint8Array => {
    if (size > bytes.length - offset) malformedExr("DWA section length");
    const result = bytes.subarray(offset, offset + size); offset += size; return result;
  };
  if (acSize) {
    if (acCompression === 0) validateHuffman(section(acSize));
    else {
      inflateBounded(section(acSize), blocks * 128, acCount * 2);
      // r185 EXRLoader uses totalAcUncompressedCount as the compressed byte span
      // in its DEFLATE branch. That field is not otherwise consumed in this branch.
      // Validate the real count first, then fix only this private decoding copy.
      view.setBigUint64(64, BigInt(acSize), true);
    }
  }
  if (dcSize) inflateBounded(section(dcSize), blocks * 2, dcCount * 2);
  if (rleRaw) {
    const encoded = inflateBounded(section(rleSize), pixels * 2, rleEncoded, true)!;
    validateRle(encoded, rleRaw);
  }
  if (offset !== bytes.length) malformedExr("DWA trailing bytes");
}
