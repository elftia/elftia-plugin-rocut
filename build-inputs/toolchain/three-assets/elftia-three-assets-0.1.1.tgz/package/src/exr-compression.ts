import { Unzlib } from "three/addons/libs/fflate.module.js";
import { AssetError } from "./types.js";

export function malformedExr(detail: string): never { throw new AssetError("INVALID_ASSET", `Malformed EXR ${detail}`); }

export function validateRle(bytes: Uint8Array, expected: number): void {
  let output = 0;
  for (let offset = 0; offset < bytes.length;) {
    const raw = bytes[offset++]!;
    const count = raw < 128 ? raw : raw - 256;
    output += count < 0 ? -count : count + 1;
    offset += count < 0 ? -count : 1;
    if (output > expected || offset > bytes.length) malformedExr("RLE block");
  }
  if (output !== expected) malformedExr("RLE output length");
}

export function inflateBounded(bytes: Uint8Array, maximum: number, expected?: number, collect = false): Uint8Array | undefined {
  let output = 0;
  const parts: Uint8Array[] = [];
  const stream = new Unzlib((chunk) => {
    output += chunk.length;
    if (output > maximum) throw new AssetError("LIMIT_EXCEEDED", "EXR ZIP block expands beyond declared dimensions");
    if (collect) parts.push(chunk.slice());
  });
  // Bound per-push allocation before Three's whole-block unzlibSync call.
  for (let offset = 0; offset < bytes.length; offset += 64) stream.push(bytes.subarray(offset, offset + 64), offset + 64 >= bytes.length);
  if (expected !== undefined && output !== expected) malformedExr("ZIP output length");
  if (!collect) return undefined;
  const result = new Uint8Array(output);
  let offset = 0;
  for (const part of parts) { result.set(part, offset); offset += part.length; }
  return result;
}

export function validateHuffman(bytes: Uint8Array): void {
  if (bytes.length < 20) malformedExr("Huffman header");
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const first = view.getUint32(0, true), last = view.getUint32(4, true);
  const tableBytes = view.getUint32(8, true), bits = view.getUint32(12, true);
  if (first > last || last > 65536 || tableBytes > bytes.length - 20 || bits > (bytes.length - 20 - tableBytes) * 8) malformedExr("Huffman bounds");
}
