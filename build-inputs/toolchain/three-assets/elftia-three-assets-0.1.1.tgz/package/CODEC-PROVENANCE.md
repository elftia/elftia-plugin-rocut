# Offline model codecs

The package includes a fixed Draco decoder and Basis Universal transcoder from
Three.js 0.185.1. These payloads are part of the package, not runtime downloads.
Three.js retains its MIT license; the codec payloads retain Apache-2.0 licenses.
See `DRACO-PROVENANCE.md`, `DRACO-LICENSE.txt` and
`src/ktx2-basis-{README.md,LICENSE.txt}`.

Basis inputs are `examples/jsm/libs/basis/basis_transcoder.js` (SHA-256
`8478b5b6d6b74e7d3082b89f6417321d8d1dc0307f2b30d4484bb11b441696a1`)
and `basis_transcoder.wasm` (SHA-256
`6cf17dc889352c42e9acf8897107978d127005fe3386c36a0e3845e27967630a`).
The JS UMD export is mechanically converted to ESM, Node filesystem discovery
is disabled, and its heap-growth limit is reduced to 64 MiB. The original WASM
bytes are embedded as base64 in `src/ktx2-wasm.ts`. No author-selected decoder,
URL or worker is accepted.

The supported KTX2 subset is non-array, single-face 2D LDR ETC1S/BasisLZ and
UASTC without supercompression. HDR, Zstd, video, premultiplied alpha,
3D/array/cube, non-default orientation and swizzle are rejected. Encoded input
is limited to 16 MiB and decoded RGBA mips to 32 MiB, additionally respecting
smaller caller limits and the aggregate GLB budget. Draco supports admitted
indexed triangle primitives with bounded attributes, indices and scratch heap.

New package consumers must rebuild the package archive and explicitly compile
with its new dependency lock. Prior package installations do not gain codecs
from a source-only change. Browser, complete export and installation acceptance
are separate from direct CPU checks.
