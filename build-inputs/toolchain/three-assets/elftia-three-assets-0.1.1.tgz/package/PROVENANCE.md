# Source and permission record

This package extracts the resource-loading responsibility of Director's
`apps/studio-web/src/components/RuntimeAsset.tsx` into a framework-independent
implementation. Reference Director base commit:
`8bc5636aa889ca7e0a36a07cda41d091354e7382`.

On 2026-10-07 the project owner explicitly confirmed, in the development
conversation, ownership of the right to relicense the selected Director loading
code and consent to the shared package using MIT:

> 拥有重新许可权，同意共享包采用 MIT

The MIT grant applies only to this package. Director's root and other packages
remain AGPL-3.0-only. This record does not relicense any third-party code.

Three.js 0.185.1 is an exact peer dependency under its upstream MIT license. Its
loaders and SkeletonUtils are imported, not vendored. Distributors must preserve
Three.js's own copyright/license notices in addition to this package's LICENSE.

The package includes the fixed offline Draco JavaScript decoder and Basis
Universal JavaScript transcoder distributed with Three.js 0.185.1, including
the Basis transcoder WASM bytes embedded in `src/ktx2-wasm.ts`. These codec
payloads retain their Apache-2.0 licenses; this package's MIT grant does not
relicense them. See [Draco provenance](DRACO-PROVENANCE.md),
[Draco license](DRACO-LICENSE.txt), [codec provenance](CODEC-PROVENANCE.md),
[Basis README](src/ktx2-basis-README.md) and
[Basis license](src/ktx2-basis-LICENSE.txt) for notices and the recorded offline
adaptations. No external decoder script, WASM, worker or author-selected URL
is loaded.

There is no Canvas UI, React, VRM, model, font, or commercial asset included in
this package. Canvas UI redistribution permission is a separate gate.
